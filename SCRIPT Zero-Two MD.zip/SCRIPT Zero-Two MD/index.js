const { Telegraf, session } = require('telegraf');
const fs = require("fs");
const P = require("pino");
const crypto = require("crypto");
const path = require("path");
const sessions = new Map();
const readline = require("readline");
const fetch = require("node-fetch");
const chalk = require("chalk"); //
const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");
const USERS_DB = './database/users.json';
const axios = require("axios");
const BOT_TOKEN = config.BOT_TOKEN;
const { ADMIN_ID } = require('./config');
const bot = new TelegramBot(BOT_TOKEN, { polling: true });
let groupFile = 'groupList.json';
if (!fs.existsSync(groupFile)) fs.writeFileSync(groupFile, '[]');

bot.on('new_chat_members', (msg) => {
  const chat = msg.chat;
  if (chat.type === 'group' || chat.type === 'supergroup') {
    let groupList = JSON.parse(fs.readFileSync(groupFile));
    if (!groupList.some(g => g.id === chat.id)) {
      groupList.push({ id: chat.id, title: chat.title });
      fs.writeFileSync(groupFile, JSON.stringify(groupList, null, 2));
    }
    bot.sendMessage(chat.id, '✅ BOT TELEGRAM TELAH SUKSES BERGABUNG DI GRUP ' + chat.title.toUpperCase());
  }
});
const groupList = JSON.parse(fs.readFileSync(groupFile));
  let count = 0;

// Saat bot ditambahkan ke grup
bot.on('new_chat_members', (msg) => {
  const newMembers = msg.new_chat_members;
  newMembers.forEach(member => {
    if (member.username === bot.username) {
      const groupId = msg.chat.id;
      const groupName = msg.chat.title;

      bot.sendMessage(groupId, `Halo grup *${groupName}*! 👋\nAku siap membantu di sini.`, {
        parse_mode: "Markdown"
      });
      saveGroupId(groupId);
    }
  });
});

bot.onText(/\/jasher (.+)/, async (msg, match) => {
  const text = match[1];
  if (msg.from.id.toString() !== ADMIN_ID.toString()) return;

  const groupList = JSON.parse(fs.readFileSync(groupFile));
  let count = 0;

  for (const group of groupList) {
    try {
      await bot.sendMessage(group.id, `📢 Broadcast:
${text}`);
      count++;
    } catch (err) {}
  }

  bot.sendMessage(ADMIN_ID,
`\`\`\`
✅ DONE BROADCAST KE ${count} GRUP
\`\`\``,
                   {
        parse_mode: "Markdown",
        reply_markup: {
        inline_keyboard: [
            [{text:" 𝕁𝕆𝕀ℕ ℂℍ𝔸ℕℕ𝔼𝕃 ", url: "https://t.me/AllAboutZeroTwo" }]
          ]
        },
      }
                 
    );
    });

bot.onText(/\/jasher2/, async (msg) => {
  if (msg.from.id.toString() !== ADMIN_ID.toString()) return;
  const reply = msg.reply_to_message;
  if (!reply) return bot.sendMessage(msg.chat.id, '❌ Balas media yang ingin dikirim.');

  const groupList = JSON.parse(fs.readFileSync(groupFile));
  let count = 0;

  for (const group of groupList) {
    try {
      if (reply.photo) {
        const fileId = reply.photo[reply.photo.length - 1].file_id;
        await bot.sendPhoto(group.id, fileId, { caption: reply.caption || '' });
      } else if (reply.video) {
        await bot.sendVideo(group.id, reply.video.file_id, { caption: reply.caption || '' });
      } else if (reply.text) {
        await bot.sendMessage(group.id, reply.text);
      }
      count++;
    } catch (err) {}
  }
    
bot.sendMessage(ADMIN_ID,
`\`\`\`
✅ DONE BROADCAST KE ${count} GRUP
\`\`\``,
                   {
        parse_mode: "Markdown",
        reply_markup: {
        inline_keyboard: [
            [{text:" 𝕁𝕆𝕀ℕ ℂℍ𝔸ℕℕ𝔼𝕃 ", url: "https://t.me/AllAboutZeroTwo" }]
          ]
        },
      }
                 
    );
    });


let premiumUsers = JSON.parse(fs.readFileSync('./premium.json'));
let adminUsers = JSON.parse(fs.readFileSync('./admin.json'));

function ensureFileExists(filePath, defaultData = []) {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
    }
}

ensureFileExists('./premium.json');
ensureFileExists('./admin.json');


function savePremiumUsers() {
    fs.writeFileSync('./premium.json', JSON.stringify(premiumUsers, null, 2));
}

function saveAdminUsers() {
    fs.writeFileSync('./admin.json', JSON.stringify(adminUsers, null, 2));
}
// Muat pengguna
function loadUsers() {
  try {
    if (fs.existsSync(USERS_DB)) {
      const data = fs.readFileSync(USERS_DB, "utf-8");
      return new Set(JSON.parse(data));
    }
    return new Set();
  } catch (error) {
    console.log("Gagal memuat pengguna dari JSON", error);
    return new Set();
  }
}

// Load & save user functions
const getUsers = async () => {
  try {
    return await fs.readJson(USERS_DB);
  } catch {
    return [];
  }
};
const saveUser = async (id) => {
  const users = await getUsers();
  if (!users.includes(id)) {
    users.push(id);
    await fs.write(USERS_DB, users);
  }
};

// Fungsi untuk memantau perubahan file
function watchFile(filePath, updateCallback) {
    fs.watch(filePath, (eventType) => {
        if (eventType === 'change') {
            try {
                const updatedData = JSON.parse(fs.readFileSync(filePath));
                updateCallback(updatedData);
                console.log(`File ${filePath} updated successfully.`);
            } catch (error) {
                console.error(`Error updating ${filePath}:`, error.message);
            }
        }
    });
}

watchFile('./premium.json', (data) => (premiumUsers = data));
watchFile('./admin.json', (data) => (adminUsers = data));

// -------( Fungsional Function Before Parameters )--------- \\
function formatRuntime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${secs} Detik`;
}

const startTime = Math.floor(Date.now() / 1000); 

function getBotRuntime() {
  const now = Math.floor(Date.now() / 1000);
  return formatRuntime(now - startTime);
}

function getGreeting() {
  const hours = new Date().getHours();
  if (hours >= 0 && hours < 12) {
    return "GoodMoorning...";
  } else if (hours >= 12 && hours < 18) {
    return "GoodAfternoon...";
  } else {
    return "GoodNigth...";
  }
}

//~ Date Now
function getCurrentDate() {
  const now = new Date();
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  return now.toLocaleDateString("id-ID", options); 
}

async function tiktokDl(url) {
  return new Promise(async (resolve, reject) => {
    try {
      let data = [];
      function formatNumber(integer) {
        return Number(parseInt(integer)).toLocaleString().replace(/,/g, ".");
      }

      function formatDate(n, locale = "id-ID") {
        let d = new Date(n);
        return d.toLocaleDateString(locale, {
          weekday: "long",
          day: "numeric",
          month: "long",
          year: "numeric",
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
        });
      }

      let domain = "https://www.tikwm.com/api/";
      let res = await (
        await axios.post(
          domain,
          {},
          {
            headers: {
              Accept: "application/json, text/javascript, */*; q=0.01",
              "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
              "Content-Type":
                "application/x-www-form-urlencoded; charset=UTF-8",
              Origin: "https://www.tikwm.com",
              Referer: "https://www.tikwm.com/",
              "User-Agent":
                "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
            },
            params: {
              url: url,
              count: 12,
              cursor: 0,
              web: 1,
              hd: 2,
            },
          }
        )
      ).data.data;

      if (!res) return reject("⚠️ *Gagal mengambil data!*");

      if (res.duration == 0) {
        res.images.forEach((v) => {
          data.push({ type: "photo", url: v });
        });
      } else {
        data.push(
          {
            type: "watermark",
            url: "https://www.tikwm.com" + res?.wmplay || "/undefined",
          },
          {
            type: "nowatermark",
            url: "https://www.tikwm.com" + res?.play || "/undefined",
          },
          {
            type: "nowatermark_hd",
            url: "https://www.tikwm.com" + res?.hdplay || "/undefined",
          }
        );
      }

      resolve({
        status: true,
        title: res.title,
        taken_at: formatDate(res.create_time).replace("1970", ""),
        region: res.region,
        id: res.id,
        duration: res.duration + " detik",
        cover: "https://www.tikwm.com" + res.cover,
        stats: {
          views: formatNumber(res.play_count),
          likes: formatNumber(res.digg_count),
          comment: formatNumber(res.comment_count),
          share: formatNumber(res.share_count),
          download: formatNumber(res.download_count),
        },
        author: {
          id: res.author.id,
          fullname: res.author.unique_id,
          nickname: res.author.nickname,
          avatar: "https://www.tikwm.com" + res.author.avatar,
        },
        video_links: data,
      });
    } catch (e) {
      reject("⚠️ *Terjadi kesalahan saat mengambil video!*");
    }
  });
}


function getPremiumStatus(userId) {
  const user = premiumUsers.find((user) => user.id === userId);
  if (user && new Date(user.expiresAt) > new Date()) {
    return `DONTOL DAH PREM`;
  } else {
    return "DONTOL BELUM PREM";
  }
}

function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

const bugRequests = {};
// Handler untuk /start

async function checkChannelMembership(bot, userId) {
  try {
    const res = await bot.getChatMember("@AllAboutZeroTwo", userId);
    return !["left", "kicked"].includes(res.status);
  } catch (e) {
    return false;
  }
}

bot.onText(/\/users/, (msg) => {
  const senderId = msg.from.id.toString();
  const chatId = msg.chat.id;
  if (senderId !== ADMIN_ID.toString()) {
    return bot.sendMessage(chatId, "❌ Kamu tidak punya izin mengakses perintah ini.");
  }
  const userDataFile = './userData.json';
  if (!fs.existsSync(userDataFile)) {
    return bot.sendMessage(chatId, "📁 Belum ada data pengguna yang tersimpan.");
  }
  const userData = JSON.parse(fs.readFileSync(userDataFile));
  const total = userData.length;

  // Bikin ringkasan user
  let text = `👥 *Total Pengguna:* ${total}\n\n`;

  userData.slice(0, 50).forEach((u, i) => {
    text += `*${i + 1}.* \`${u.id}\`\n👤 ${u.first_name}\n🏷 ${u.username}\n📆 ${new Date(u.registered_at).toLocaleString()}\n\n`;
  });

  // Kirim data (maksimal 50 user ditampilkan langsung)
  bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
});

// INI LU BISA HAPUS/GA NYA,SOALNYA SAMA AJA,ITU AWALNYA BOT.ON.TEXT /start CUMA BEDA FITUR
bot.onText(/\/percobaan/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
  const premiumStatus = getPremiumStatus(senderId); 
// fungsi milikmu
  const runtime = getBotRuntime();
// fungsi milikmu
  const selamat = getGreeting(); 
// fungsi milikmu

  // Cek apakah user sudah join channel
  const isMember = await checkChannelMembership(bot, senderId);
  if (!isMember) {
    return bot.sendMessage(chatId,
      "```\nʟᴜ ᴍᴀᴜ ɴɢᴀᴘᴀɪɴ ᴛᴏʟᴏʟ ᴡᴋᴡᴋᴡᴋ\nᴊᴏɪɴ ᴅᴜʟᴜ ꜱᴀɴᴀ ʙᴀʀᴜ ʙɪꜱᴀ ᴍᴀᴋᴇ\nᴅɪᴋᴀꜱɪ ꜰʀᴇᴇ ɴɢᴇʟᴜɴᴊᴀᴋ ʟᴜ ɪᴅɪᴏᴛ!!\n```",
      {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "𝕁𝕆𝕀ℕ ℂℍ𝔸ℕℕ𝔼𝕃", url: "https://t.me/AllAboutZeroTwo" }]
          ]
        }
      }
    );
  }

  // Jika sudah join, kirim foto dan menu utama
  bot.sendPhoto(chatId, "https://files.catbox.moe/e69fx0.jpg", {
    caption: `\`\`\`こんにちは
AUTHOR         : @xlilnyx
NAME SCRIPT    : ZeroTwo-MD
VERSION        : 1.0.0
MODULE         : Node-ApiKey
USER           : ${username}
USER ID        : ${senderId}
STATUS         : ${premiumStatus}
\`\`\``,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "ADD TO GROUP", url: `https://t.me/${bot.username}?startgroup=true` }],
         [{ text: "[ INFO NEXT VERSION ]", url: "https://t.me/AllAboutZeroTwo" }],
        [{ text: "[ ALL MENU ]", callback_data: "allmenu" }]
      ]
    }
  });
});

// CASE START BOT,INGAT² JAN SAMPE KETUKER SAMA YANG ATAS,KARENA BEDA FITUR BEDA FUNGSI
const userListFile = './userList.json';
const userDataFile = './userData.json';

bot.getMe().then(info => {
  bot.username = info.username;

  bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
    const firstName = msg.from.first_name || "Tidak diketahui";
    const premiumStatus = getPremiumStatus(senderId);
    const isBot = msg.from.is_bot ? "BOT" : "HUMAN";

    // Cek keanggotaan channel
    const isMember = await checkChannelMembership(bot, senderId);
    if (!isMember) {
      return bot.sendMessage(chatId, "❌ Join dulu channel sebelum menggunakan bot!", {
        reply_markup: {
          inline_keyboard: [
            [{ text: "JOIN CHANNEL", url: "https://t.me/AllAboutZeroTwo" }]
          ]
        },
        parse_mode: "Markdown"
      });
    }

    // Simpan ID ke userList.json
    let userList = [];
    if (fs.existsSync(userListFile)) {
      userList = JSON.parse(fs.readFileSync(userListFile));
    }
    const isNewUser = !userList.includes(senderId);
    if (isNewUser) {
      userList.push(senderId);
      fs.writeFileSync(userListFile, JSON.stringify(userList, null, 2));
    }

    // Simpan data lengkap ke userData.json
    let userData = [];
    if (fs.existsSync(userDataFile)) {
      userData = JSON.parse(fs.readFileSync(userDataFile));
    }
    const alreadySaved = userData.some(u => u.id === senderId);
    if (!alreadySaved) {
      userData.push({
        id: senderId,
        username,
        first_name: firstName,
        registered_at: new Date().toISOString()
      });
      fs.writeFileSync(userDataFile, JSON.stringify(userData, null, 2));
    }

    // Ambil lokasi IP (lokasi server bot)
    let locationText = "🌐 Lokasi tidak diketahui";
    try {
      const ipInfo = await axios.get(`http://ip-api.com/json`);
      locationText = `🌍 Negara: ${ipInfo.data.country || 'Tidak diketahui'}`;
    } catch (e) {
      locationText = "🌐 Gagal ambil lokasi";
    }

    // Kirim menu utama
    bot.sendPhoto(chatId, "https://files.catbox.moe/e69fx0.jpg", {
      caption: `\`\`\`こんにちは
AUTHOR         : @xlilnyx
NAME SCRIPT    : ZeroTwo-MD
VERSION        : 1.0.0
MODULE         : Node-ApiKey
USER           : ${username}
USER ID        : ${senderId}
STATUS         : ${premiumStatus}
\`\`\``,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "ADD TO GROUP", url: `https://t.me/${bot.username}?startgroup=true` }],
          [{ text: "[ INFO NEXT VERSION ]", url: "https://t.me/AllAboutZeroTwo" }],
          [{ text: "[ ALL MENU ]", callback_data: "allmenu" }]
        ]
      }
    });

    // Kirim notifikasi ke owner
    const ownerNotif = `
*NOTIFICATION,THERE'S SOMEONE*
*NEW USING YOUR BOT,THANKYOU*

User   : ${username}
ID        : ${senderId}
Tipe    : ${isBot}
Total   : *${userList.length} Users*
Waktu : ${new Date().toLocaleString()}
`;

    bot.sendMessage(ADMIN_ID, ownerNotif, { parse_mode: "Markdown" });
  });
});

bot.on("callback_query", async (query) => {
  try {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const username = query.from.username ? `@${query.from.username}` : "Tidak ada username";
    const senderId = query.from.id;
    const premiumStatus = getPremiumStatus(senderId);
    const bokepjepang = getBotRuntime();
    const selamat = getGreeting();

    let caption = "";
    let replyMarkup = {};
      
 if (query.data === "allmenu") {
      caption = `\`\`\`こんにちは
AUTHOR         : @xlilnyx
NAME SCRIPT    : ZeroTwo-MD
VERSION        : 1.0.0
MODULE         : Node-ApiKey
USER           : ${username}
USER ID        : ${senderId}
STATUS         : ${premiumStatus}
\`\`\``;
replyMarkup = { 
      inline_keyboard: [
          [{ text: "ɢʀᴜᴘ ᴍᴇɴᴜ", callback_data: "grup" },
           { text: "ᴛᴏᴏʟs ᴍᴇɴᴜ", callback_data: "tools" }],
        [{ text: "ᴛᴇʙᴀᴋ ᴍᴇɴᴜ", callback_data: "dox" }, { text: "sᴛᴀʟᴋ ᴍᴇɴᴜ", callback_data: "stalk" }],
        [{ text: "ᴄᴇᴋ ᴍᴇɴᴜ", callback_data: "cek" }, { text: "ɢᴀᴍᴇ ᴍᴇɴᴜ", callback_data: "game" }],
        [{ text: "ᴏᴡɴᴇʀ ᴍᴇɴᴜ", callback_data: "ownmenu" }, { text: "ʀᴀɴᴅᴏᴍ ᴍᴇɴᴜ", callback_data: "random" }],
          [{ text: "ʙᴀᴄᴋ ᴍᴇɴᴜ", callback_data: "back" }]
      ]
   };
    }
      
      
    if (query.data === "random") {
      caption = `\`\`\`
/cekid
/xid
/info
/profil
/nulis
/ai
/gpt
/done
/pakustad
/waifu
/fixcode
/fixcode2
/fixcodeerror
/editcode
\`\`\``;
      replyMarkup = { 
      inline_keyboard: [
          [{ text: "ʙᴀᴄᴋ ᴍᴇɴᴜ", callback_data: "back" }],
          [{ text: "[ INFO NEXT VERSION ]", url: "https://t.me/AllAboutZeroTwo" }]
      ]
   };
    }

    if (query.data === "ownmenu") {
      caption = `\`\`\`
/users
/addowner
/delowner
/addprem
/delprem
/listprem
/panel
/listsrv
/delsrv
\`\`\``;
      replyMarkup = { inline_keyboard: [
          [{ text: "ʙᴀᴄᴋ ᴍᴇɴᴜ", callback_data: "back" }],
          [{ text: "[ INFO NEXT VERSION ]", url: "https://t.me/AllAboutZeroTwo" }]
      ]};
    }
    
        if (query.data === "tools") {
      caption = `\`\`\`
/tiktok
/tourl
/brat
/qc
/stiktok
/translate
/play
/mediafire
/infogempa
/xnxx
/getcode
/getcodezip
\`\`\``;
      replyMarkup = { inline_keyboard: [
          [{ text: "ʙᴀᴄᴋ ᴍᴇɴᴜ", callback_data: "back" }],
          [{ text: "[ INFO NEXT VERSION ]", url: "https://t.me/AllAboutZeroTwo" }]
                                       ] };
    }
    
    if (query.data === "grup") {
      caption = `\`\`\`
/cfdgroup
/addgroupid
/delgroupid
/listgroupid
/listusr
/mute
/unmute
/ban
/unban
/kick
/invite
/broadcast
/jasher1
/jasher2
\`\`\``;
      replyMarkup = { inline_keyboard: [
          [{ text: "ʙᴀᴄᴋ ᴍᴇɴᴜ", callback_data: "back" }],
          [{ text: "[ INFO NEXT VERSION ]", url: "https://t.me/AllAboutZeroTwo" }]
     ]};
    }

    if (query.data === "cek") {
      caption = `\`\`\`
/cekkhodam
/cekpacar
/cekjanda
/cekmiskin
/cekkaya
/cekcantik
/cektampan
/ceklokasi
/ceksedangapa
/script
\`\`\``;
      replyMarkup = { inline_keyboard: [
          [{ text: "ʙᴀᴄᴋ ᴍᴇɴᴜ", callback_data: "back" }],
          [{ text: "[ INFO NEXT VERSION ]", url: "https://t.me/AllAboutZeroTwo" }]
        ]};
    }

    if (query.data === "game") {
      caption = `\`\`\`
#catur
/catur
/move
/resign

#tictactoe
/tictactoe

#bola
/mainbola <Lawan Bot>
/mainbola2 <Multi Player>

#Per-perangan
/perang
/gabungperang
/serang
/nyerah

#Balapan
/balap
/gas
/balappoint
/upgrade

#asah-otak
/asahotak
/lewati
/petunjuk
\`\`\``;
      replyMarkup = { inline_keyboard: [
          [{ text: "ʙᴀᴄᴋ ᴍᴇɴᴜ", callback_data: "back" }],
          [{ text: "[ INFO NEXT VERSION ]", url: "https://t.me/AllAboutZeroTwo" }]
 ]};
    }

    if (query.data === "dox") {
      caption = `\`\`\`
/tebakkabupaten
/tebakbendera
/tebakgambar
/tebakkata
/tebaklirik
/tebaktebakan
/leaderboard
/hint
/skip
\`\`\``;
      replyMarkup = { inline_keyboard: [
          [{ text: "ʙᴀᴄᴋ ᴍᴇɴᴜ", callback_data: "back" }],
          [{ text: "[ INFO NEXT VERSION ]", url: "https://t.me/AllAboutZeroTwo" }]
    ]
    };
    }

    if (query.data === "stalk") {
      caption = `\`\`\`
/instagramstalk
/pintereststalk
/threadsstalk
/tiktokstalk
/twitterstalk
/githubstalk
/youtubestalk
/stalkff
/stalkmlbb
\`\`\``;
      replyMarkup = { inline_keyboard: [
          [{ text: "ʙᴀᴄᴋ ᴍᴇɴᴜ", callback_data: "back" }],
          [{ text: "[ INFO NEXT VERSION ]", url: "https://t.me/AllAboutZeroTwo" }]
           ]};
    }

    if (query.data === "back") {
      caption = `\`\`\`こんにちは
AUTHOR         : @xlilnyx
NAME SCRIPT    : ZeroTwo-MD
VERSION        : 1.0.0
MODULE         : Node-ApiKey
USER           : ${username}
USER ID        : ${senderId}
STATUS         : ${premiumStatus}
\`\`\``,
      replyMarkup = {
      inline_keyboard: [
          [{ text: "ADD TO GROUP", url: `https://t.me/${bot.username}?startgroup=true` }],
          [{ text: "[ INFO NEXT VERSION ]", url: "https://t.me/AllAboutZeroTwo" }],
        [{ text: "[ ALL MENU ]", callback_data: "allmenu" }]
      ]
      };
    }

    await bot.editMessageMedia(
      {
        type: "photo",
        media: "https://files.catbox.moe/e69fx0.jpg",
        
        caption: caption,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
      }
    );

    await bot.answerCallbackQuery(query.id);
  } catch (error) {
    console.error("Error handling callback query:", error);
  }
});

//PLUGIN
bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
      return bot.sendMessage(chatId, "❌ You are not authorized to admin users.");
  }

  if (!match[1]) {
      return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID and duration. Example: /addprem 123456789 30d.");
  }

  const args = match[1].split(' ');
  if (args.length < 2) {
      return bot.sendMessage(chatId, "❌ Missing input. Please specify a duration. Example: /addprem 123456789 30d.");
  }

  const userId = parseInt(args[0].replace(/[^0-9]/g, ''));
  const duration = args[1];
  
  if (!/^\d+$/.test(userId)) {
      return bot.sendMessage(chatId, "❌ Invalid input. User ID must be a number. Example: /addprem 123456789 30d.");
  }
  
  if (!/^\d+[dhm]$/.test(duration)) {
      return bot.sendMessage(chatId, "❌ Invalid duration format. Use numbers followed by d (days), h (hours), or m (minutes). Example: 30d.");
  }

  const now = moment();
  const expirationDate = moment().add(parseInt(duration), duration.slice(-1) === 'd' ? 'days' : duration.slice(-1) === 'h' ? 'hours' : 'minutes');

  if (!premiumUsers.find(user => user.id === userId)) {
      premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
      savePremiumUsers();
      console.log(`${senderId} added ${userId} to Prem until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}`);
      bot.sendMessage(chatId, `✅ User ${userId} has been added to the Prem list until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  } else {
      const existingUser = premiumUsers.find(user => user.id === userId);
      existingUser.expiresAt = expirationDate.toISOString(); // Extend expiration
      savePremiumUsers();
      bot.sendMessage(chatId, `✅ User ${userId} is already a Vip user. Expiration extended until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  }
});

bot.onText(/\/listprem/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ You are not authorized to view the Vip list.");
  }

  if (premiumUsers.length === 0) {
    return bot.sendMessage(chatId, "📌 No Vip users found.");
  }

  let message = "𝐋𝐈𝐒𝐓 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 ‼️";
  premiumUsers.forEach((user, index) => {
    const expiresAt = moment(user.expiresAt).format('YYYY-MM-DD HH:mm:ss');
    message += `${index + 1}. ID: \`${user.id}\`\n   Expiration: ${expiresAt}\n\n`;
  });

  bot.sendMessage(chatId, message, { parse_mode: "Markdown" });
});
//=====================================
bot.onText(/\/addowner(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id

    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /addadmin 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /addadmin 6843967527.");
    }

    if (!adminUsers.includes(userId)) {
        adminUsers.push(userId);
        saveAdminUsers();
        console.log(`${senderId} Added ${userId} To Admin`);
        bot.sendMessage(chatId, `✅ User ${userId} has been added as an admin.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is already an admin.`);
    }
});

bot.onText(/\/delprem(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // Cek apakah pengguna adalah owner atau admin
    if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to remove Vip users.");
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Please provide a user ID. Example: /delvip 123456789");
    }

    const userId = parseInt(match[1]);

    if (isNaN(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. User ID must be a number.");
    }

    // Cari index user dalam daftar premium
    const index = premiumUsers.findIndex(user => user.id === userId);
    if (index === -1) {
        return bot.sendMessage(chatId, `❌ User ${userId} is not in the Vip list.`);
    }

    // Hapus user dari daftar
    premiumUsers.splice(index, 1);
    savePremiumUsers();
    bot.sendMessage(chatId, `✅ User ${userId} has been removed from the regis list.`);
});

bot.onText(/\/delowner(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // Cek apakah pengguna memiliki izin (hanya pemilik yang bisa menjalankan perintah ini)
    if (!isOwner(senderId)) {
        return bot.sendMessage(
            chatId,
            "⚠️ Akses Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
            { parse_mode: "Markdown" }
        );
    }

    // Pengecekan input dari pengguna
    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /deladmin 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /deladmin 6843967527.");
    }

    // Cari dan hapus user dari adminUsers
    const adminIndex = adminUsers.indexOf(userId);
    if (adminIndex !== -1) {
        adminUsers.splice(adminIndex, 1);
        saveAdminUsers();
        console.log(`${senderId} Removed ${userId} From Admin`);
        bot.sendMessage(chatId, `✅ User ${userId} has been removed from admin.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is not an admin.`);
    }
});

const moment = require('moment-timezone');

let enabled = true;

bot.on('message', (msg) => {
  if (!enabled) return;

  const username = msg.from.username
    ? chalk.yellow.bold(`@${msg.from.username}`)
    : chalk.yellow.bold(msg.from.first_name || 'Pengguna Tidak Diketahui');

  const text = msg.text
    ? chalk.blue.bold(msg.text)
    : chalk.gray.bold('[Non-teks]');

  const chatType = msg.chat.type;
  const chatName = chatType === 'private'
    ? chalk.magenta.bold('Private Chat')
    : chalk.magenta.bold(msg.chat.title);

  const timeStamp = chalk.blue.bold(moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss'));

  const frames1 = [`
${chalk.red.bold(`
            _______  
           /       /
  ___     /   ____/    
  :   :  /   /: 
   :   :/___/  : 
    :       :   : 
     :_______:   : 
             /   /    
            /   / 
            :  / 
             :/ 
`)}
`];
    
  const logText = `
${chalk.white.bold(' ZeroTwo-MD - Log Pesan Masuk   ')}
${chalk.green.bold('TIME      :')} ${timeStamp}
${chalk.green.bold('USERS     :')} ${username}
${chalk.green.bold('LOCATIONS :')} ${chatName}
${chalk.green.bold('AUTHOR    : XLILNYX')}
${chalk.green.bold('CHAT      :')} ${text}
`;
  console.clear();
  console.log(frames1 + logText);
});
    process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));

// Kalau mau mengaktifkan / menonaktifkan secara manual (opsional)
function enableLogger() {
  enabled = true;
  console.log('[PLUGIN] Logger diaktifkan');
}

function disableLogger() {
  enabled = false;
  console.log('[PLUGIN] Logger dinonaktifkan');
}

// Load daftar pengguna dari file (optional)
let users = new Set();
const usersPath = './data/users.json';

if (fs.existsSync(usersPath)) {
    try {
        const raw = JSON.parse(fs.readFileSync(usersPath));
        users = new Set(raw);
    } catch (e) {
        console.error('Gagal memuat users.json:', e);
    }
}

bot.onText(/^\/listusr$/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    // Hanya untuk owner
    if (!isOwner(userId)) {
        return bot.sendMessage(chatId, '❌ Akses Ditolak: Perintah ini hanya untuk owner!', {
            parse_mode: 'Markdown'
        });
    }

    if (users.size === 0) {
        return bot.sendMessage(chatId, '📋 Tidak ada pengguna yang terdaftar.');
    }

    let userList = '📋 Daftar Pengguna Bot:\n';

    const userData = await Promise.all([...users].map(async (id, index) => {
        try {
            const user = await bot.getChat(id);
            const username = user.username ? `(@${user.username})` : '';
            return `${index + 1}. \`${id}\` ${username}`;
        } catch (err) {
            return `${index + 1}. \`${id}\` (Tidak dapat mengambil info)`;
        }
    }));

    userList += userData.join('\n');

    bot.sendMessage(chatId, userList, { parse_mode: 'Markdown' });
});

bot.onText(/^\/mute$/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;

    // Harus reply pesan
    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Balas pesan pengguna yang ingin di-mute.');
    }

    const targetUser = msg.reply_to_message.from;

    try {
        // Cek apakah yang memanggil adalah admin
        const admins = await bot.getChatAdministrators(chatId);
        const isAdmin = admins.some(admin => admin.user.id === fromId);
        if (!isAdmin) {
            return bot.sendMessage(chatId, '❌ Hanya admin yang bisa menggunakan perintah ini.');
        }

        // Mute user: hanya non-admin yang bisa dimute
        await bot.restrictChatMember(chatId, targetUser.id, {
            permissions: {
                can_send_messages: false,
                can_send_media_messages: false,
                can_send_polls: false,
                can_send_other_messages: false,
                can_add_web_page_previews: false,
                can_change_info: false,
                can_invite_users: false,
                can_pin_messages: false
            }
        });

        // Notifikasi ke grup
        await bot.sendMessage(chatId,
            `✅ Pengguna [${targetUser.first_name}](tg://user?id=${targetUser.id}) telah di-mute.`,
            { parse_mode: 'Markdown' });

        // Balas pesan yang dimute
        await bot.sendMessage(chatId,
            '🚫 Pengguna telah di-mute di grup ini oleh admin.',
            {
                parse_mode: 'Markdown',
                reply_to_message_id: msg.reply_to_message.message_id
            });

    } catch (err) {
        console.error('❌ Error saat mute:', err);
        bot.sendMessage(chatId, '❌ Gagal melakukan mute.');
    }
});

bot.onText(/^\/unmute$/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;

    // Harus membalas pesan
    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Balas pesan pengguna yang ingin di-unmute.');
    }

    const targetUser = msg.reply_to_message.from;

    try {
        // Cek apakah pengirim adalah admin
        const admins = await bot.getChatAdministrators(chatId);
        const isAdmin = admins.some(admin => admin.user.id === fromId);
        if (!isAdmin) {
            return bot.sendMessage(chatId, '❌ Hanya admin yang bisa menggunakan perintah ini.');
        }

        // Unmute pengguna
        await bot.restrictChatMember(chatId, targetUser.id, {
            permissions: {
                can_send_messages: true,
                can_send_media_messages: true,
                can_send_polls: true,
                can_send_other_messages: true,
                can_add_web_page_previews: true,
                can_invite_users: true,
                can_pin_messages: false,  // Bisa disesuaikan
                can_change_info: false    // Bisa disesuaikan
            }
        });

        // Notifikasi ke grup
        await bot.sendMessage(chatId,
            `✅ Pengguna [${targetUser.first_name}](tg://user?id=${targetUser.id}) telah di-unmute.`,
            { parse_mode: 'Markdown' });

        // Balas ke pesan pengguna
        await bot.sendMessage(chatId,
            '🔊 Pengguna telah di-unmute di grup ini, silakan mengobrol kembali.',
            {
                parse_mode: 'Markdown',
                reply_to_message_id: msg.reply_to_message.message_id
            });

    } catch (err) {
        console.error('❌ Error saat unmute:', err);
        bot.sendMessage(chatId, '❌ Gagal melakukan unmute.');
    }
});

bot.onText(/^\/ban$/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;

    // Harus membalas pesan
    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Balas pesan pengguna yang ingin di-ban.');
    }

    const targetUser = msg.reply_to_message.from;

    try {
        // Cek apakah pengirim adalah admin
        const admins = await bot.getChatAdministrators(chatId);
        const isAdmin = admins.some(admin => admin.user.id === fromId);
        if (!isAdmin) {
            return bot.sendMessage(chatId, '❌ Hanya admin yang bisa menggunakan perintah ini.');
        }

        // Ban pengguna
        await bot.banChatMember(chatId, targetUser.id);

        // Notifikasi ke grup
        await bot.sendMessage(chatId,
            `✅ Pengguna [${targetUser.first_name}](tg://user?id=${targetUser.id}) telah di-ban.`,
            { parse_mode: 'Markdown' });

        // Pesan follow-up di bawah reply
        await bot.sendMessage(chatId,
            '🚫 Pengguna telah di-ban dari grup ini oleh admin.',
            {
                parse_mode: 'Markdown',
                reply_to_message_id: msg.reply_to_message.message_id
            });

    } catch (err) {
        console.error('❌ Error saat ban:', err);
        bot.sendMessage(chatId, '❌ Gagal melakukan ban.');
    }
});

bot.onText(/^\/unban$/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;

    // Harus membalas pesan
    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Balas pesan pengguna yang ingin di-unban.');
    }

    const targetUser = msg.reply_to_message.from;

    try {
        // Cek apakah pengirim adalah admin
        const admins = await bot.getChatAdministrators(chatId);
        const isAdmin = admins.some(admin => admin.user.id === fromId);
        if (!isAdmin) {
            return bot.sendMessage(chatId, '❌ Hanya admin yang bisa menggunakan perintah ini.');
        }

        // Unban pengguna
        await bot.unbanChatMember(chatId, targetUser.id, {
            only_if_banned: true
        });

        // Notifikasi ke grup
        await bot.sendMessage(chatId,
            `✅ Pengguna [${targetUser.first_name}](tg://user?id=${targetUser.id}) telah di-unban.`,
            { parse_mode: 'Markdown' });

        // Pesan tambahan
        await bot.sendMessage(chatId,
            '🔓 Pengguna telah di-unban dari grup ini, silakan bergabung kembali.',
            {
                parse_mode: 'Markdown',
                reply_to_message_id: msg.reply_to_message.message_id
            });

    } catch (err) {
        console.error('❌ Error saat unban:', err);
        bot.sendMessage(chatId, '❌ Gagal melakukan unban.');
    }
});

bot.onText(/^\/kick$/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;

    // Harus membalas pesan
    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Balas pesan pengguna yang ingin di-kick.');
    }

    const targetUser = msg.reply_to_message.from;

    try {
        // Cek apakah pengirim adalah admin
        const admins = await bot.getChatAdministrators(chatId);
        const isAdmin = admins.some(admin => admin.user.id === fromId);
        if (!isAdmin) {
            return bot.sendMessage(chatId, '❌ Hanya admin yang bisa menggunakan perintah ini.');
        }

        // Kick: ban lalu unban agar bisa join lagi
        await bot.banChatMember(chatId, targetUser.id);
        await bot.unbanChatMember(chatId, targetUser.id);

        // Notifikasi ke grup
        await bot.sendMessage(chatId,
            `✅ Pengguna [${targetUser.first_name}](tg://user?id=${targetUser.id}) telah di-kick.`,
            { parse_mode: 'Markdown' });

        // Pesan tambahan sebagai reply
        await bot.sendMessage(chatId,
            'Pengguna telah di-kick dari grup ini oleh admin. Pengguna dapat bergabung kembali jika diperbolehkan.😂',
            {
                parse_mode: 'Markdown',
                reply_to_message_id: msg.reply_to_message.message_id
            });

    } catch (err) {
        console.error('❌ Error saat kick:', err);
        bot.sendMessage(chatId, '❌ Gagal melakukan kick.');
    }
});

bot.onText(/^\/invite(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id
  const chatType = msg.chat.type
  const username = match[1]?.trim()

  // Hanya bisa digunakan di grup
  if (chatType !== 'group' && chatType !== 'supergroup') {
    return bot.sendMessage(chatId, 'Perintah ini hanya dapat digunakan di dalam grup.')
  }

  // Cek apakah bot admin
  try {
    const botId = (await bot.getMe()).id
    const botMember = await bot.getChatMember(chatId, botId)
    if (!['administrator', 'creator'].includes(botMember.status)) {
      return bot.sendMessage(chatId, 'Bot harus menjadi admin terlebih dahulu.')
    }
  } catch (err) {
    return bot.sendMessage(chatId, 'Gagal memeriksa status admin bot.')
  }

  // Validasi username
  if (!username) {
    return bot.sendMessage(chatId, 'Silakan masukkan username pengguna (tanpa @).\n\nContoh:\n/invite username')
  }

  // Ambil link undangan grup
  let inviteLink
  try {
    inviteLink = await bot.exportChatInviteLink(chatId)
  } catch (err) {
    return bot.sendMessage(chatId, 'Gagal membuat link undangan. Pastikan bot adalah admin dan memiliki izin membuat link.')
  }

  // Kirim pesan pribadi ke user target
  try {
    await bot.sendMessage(`@${username}`, `≡ *UNDANGAN GRUP*\n\nSeseorang mengundang Anda untuk bergabung:\n${inviteLink}`, {
      parse_mode: 'Markdown'
    })
    bot.sendMessage(chatId, 'Link undangan berhasil dikirim ke pengguna.')
  } catch (err) {
    bot.sendMessage(chatId, 'Gagal mengirim pesan ke pengguna. Pastikan username benar dan pengguna telah memulai chat dengan bot.')
  }
})

const FormData = require('form-data');

  bot.onText(/\/tourl/i, async (msg) => {
    const chatId = msg.chat.id;

    const repliedMsg = msg.reply_to_message;
    if (!repliedMsg || (!repliedMsg.document && !repliedMsg.photo && !repliedMsg.video)) {
      return bot.sendMessage(chatId, "❌ Silakan reply sebuah file/foto/video dengan command /tourl");
    }

    let fileId, fileName;

    if (repliedMsg.document) {
      fileId = repliedMsg.document.file_id;
      fileName = repliedMsg.document.file_name || `file_${Date.now()}`;
    } else if (repliedMsg.photo) {
      const photos = repliedMsg.photo;
      fileId = photos[photos.length - 1].file_id; // ambil resolusi tertinggi
      fileName = `photo_${Date.now()}.jpg`;
    } else if (repliedMsg.video) {
      fileId = repliedMsg.video.file_id;
      fileName = `video_${Date.now()}.mp4`;
    }

    try {
      const processingMsg = await bot.sendMessage(chatId, "⏳ Mengupload ke Catbox...");

      // Ambil link file dari Telegram
      const file = await bot.getFile(fileId);
      const fileLink = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;

      const response = await axios.get(fileLink, { responseType: 'stream' });

      const form = new FormData();
      form.append('reqtype', 'fileupload');
      form.append('fileToUpload', response.data, {
        filename: fileName,
        contentType: response.headers['content-type'],
      });

      const { data: catboxUrl } = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: form.getHeaders()
      });

      if (!catboxUrl.startsWith('https://')) {
        throw new Error('Catbox tidak mengembalikan URL yang valid');
      }

      await bot.editMessageText(`✅ Upload berhasil!\n📎 URL: ${catboxUrl}`, {
        chat_id: chatId,
        message_id: processingMsg.message_id
      });

    } catch (error) {
      console.error("Upload error:", error?.response?.data || error.message);
      bot.sendMessage(chatId, "❌ Gagal mengupload file ke Catbox");
    }
  });


const cheerio = require('cheerio');
const { tmpdir } = require('os');
const { mkdirSync } = require('fs');

bot.onText(/\/getcodezip/, async (msg) => {
  const chatId = msg.chat.id;
  const reply = msg.reply_to_message;
  const url = reply?.text?.trim();

  if (!url || !url.startsWith('http')) {
    return bot.sendMessage(chatId, '❌ Reply pesan yang berisi link website valid.');
  }

  try {
    const res = await axios.get(url);
    const $ = cheerio.load(res.data);

    const baseFolder = path.join(tmpdir(), `sitecode_${Date.now()}`);
    const assetsFolder = path.join(baseFolder, 'assets');
    mkdirSync(baseFolder);
    mkdirSync(assetsFolder);

    const downloadResource = async (src, subfolder = '') => {
      try {
        const fileUrl = new URL(src, url).href;
        const fileName = path.basename(fileUrl.split('?')[0]);
        const subfolderPath = path.join(assetsFolder, subfolder);
        mkdirSync(subfolderPath, { recursive: true });
        const savePath = path.join(subfolderPath, fileName);
        const response = await axios.get(fileUrl, { responseType: 'arraybuffer' });
        await fs.writeFile(savePath, response.data);
        return `assets/${subfolder ? subfolder + '/' : ''}${fileName}`;
      } catch (e) {
        return null;
      }
    };

    const rewriteAndDownload = async (tag, attr, subfolder) => {
      const elems = $(tag);
      for (let i = 0; i < elems.length; i++) {
        const el = elems[i];
        const link = $(el).attr(attr);
        if (!link || link.startsWith('data:')) continue;
        const localPath = await downloadResource(link, subfolder);
        if (localPath) $(el).attr(attr, localPath);
      }
    };

    await rewriteAndDownload('link[rel="stylesheet"]', 'href', 'css');
    await rewriteAndDownload('script[src]', 'src', 'js');
    await rewriteAndDownload('img[src]', 'src', 'img');

    const finalHtml = $.html();
    const indexPath = path.join(baseFolder, 'index.html');
    await fs.writeFile(indexPath, finalHtml);

    const zip = new AdmZip();
    zip.addLocalFolder(baseFolder);
    const zipPath = path.join(tmpdir(), `code_${Date.now()}.zip`);
    zip.writeZip(zipPath);

    await bot.sendDocument(chatId, zipPath, {}, {
      filename: 'website_code.zip'
    });
  } catch (err) {
    console.error('Gagal ambil kode:', err);
    bot.sendMessage(chatId, '⚠️ Gagal mengambil kode dari website. Pastikan link valid dan bisa diakses.');
  }
});

bot.onText(/\/getcode/, async (msg) => {
  const chatId = msg.chat.id;
  const reply = msg.reply_to_message;

  if (!reply || !reply.text || !reply.text.startsWith("https://")) {
    return bot.sendMessage(chatId, "❌ Balas pesan yang berisi link website.");
  }

  const url = reply.text.trim();

  try {
    bot.sendMessage(chatId, "⏳ Mengambil source code dari website...");

    const response = await axios.get(url);
    const htmlContent = response.data;

    const buffer = Buffer.from(htmlContent, "utf-8");

    await bot.sendDocument(chatId, buffer, {
      filename: "source-code.html",
      caption: `📦 Ini source code dari ${url}`,
    });

  } catch (err) {
    console.error("Gagal ambil kode:", err.message);
    bot.sendMessage(chatId, "⚠️ Gagal mengambil source code dari website tersebut.");
  }
});

bot.onText(/\/stiktok(?:\s+(.+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const keyword = match[1]?.trim() || msg.reply_to_message?.text?.trim();

  if (!keyword) {
    return bot.sendMessage(chatId, '❌ Mohon masukkan kata kunci. Contoh: /stiktok sad');
  }

  try {
    const response = await axios.post('https://api.siputzx.my.id/api/s/tiktok', {
      query: keyword
    }, {
      headers: { 'Content-Type': 'application/json' }
    });

    const data = response.data;
    if (!data.status || !Array.isArray(data.data) || data.data.length === 0) {
      return bot.sendMessage(chatId, '⚠️ Tidak ditemukan video TikTok dengan kata kunci tersebut.');
    }

    const videos = data.data.slice(0, 3);
    let replyText = `🔎 Hasil pencarian TikTok untuk: *${keyword}*\n\n`;

    for (const video of videos) {
      const title = video.title?.trim() || 'Tanpa Judul';
      replyText += `🎬 *${title}*\n`;
      replyText += `👤 ${video.author.nickname} (@${video.author.unique_id})\n`;
      replyText += `▶️ [Link Video](${video.play})\n`;
      replyText += `🎵 Musik: ${video.music_info.title} - ${video.music_info.author}\n`;
      replyText += `⬇️ [Download WM](${video.wmplay})\n\n`;
    }

    bot.sendMessage(chatId, replyText, { parse_mode: 'Markdown' });

  } catch (error) {
    console.error(error?.response?.data || error.message);
    bot.sendMessage(chatId, '❌ Terjadi kesalahan saat mengambil data TikTok.');
  }
});

const { createCanvas, loadImage } = require('canvas');

bot.onText(/^\/cekid$/, async (msg) => {
  const chatId = msg.chat.id;
  const user = msg.from;

  try {
    const fullName = `${user.first_name || ''} ${user.last_name || ''}`.trim();
    const username = user.username ? `@${user.username}` : '-';
    const userId = user.id.toString();
    const today = new Date().toISOString().split('T')[0];
    const dcId = (user.id >> 32) % 256; // Estimasi data center ID

    // Ambil foto profil user
    let photoUrl = null;
    try {
      const photos = await bot.getUserProfilePhotos(user.id, { limit: 1 });
      if (photos.total_count > 0) {
        const fileId = photos.photos[0][0].file_id;
        const file = await bot.getFile(fileId);
        photoUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
      }
    } catch (e) {
      console.log('Gagal ambil foto profil:', e.message);
    }

    // Gambar background
    const canvas = createCanvas(1000, 600);
    const ctx2d = canvas.getContext('2d');

    // Background
    ctx2d.fillStyle = '#e6f2ee';
    ctx2d.fillRect(0, 0, canvas.width, canvas.height);

    // Foto user
    if (photoUrl) {
      const response = await axios.get(photoUrl, { responseType: 'arraybuffer' });
      const avatar = await loadImage(response.data);
      ctx2d.drawImage(avatar, 50, 50, 250, 300);
    } else {
      ctx2d.fillStyle = '#ccc';
      ctx2d.fillRect(50, 50, 250, 300);
    }

    // Teks
    ctx2d.fillStyle = '#0a4f44';
    ctx2d.font = 'bold 40px sans-serif';
    ctx2d.fillText('ID CARD TELEGRAM', 350, 80);

    ctx2d.fillStyle = 'black';
    ctx2d.font = '28px sans-serif';
    ctx2d.fillText(`Nama: ${fullName}`, 350, 150);
    ctx2d.fillText(`User ID: ${userId}`, 350, 200);
    ctx2d.fillText(`User Name: ${username}`, 350, 250);
    ctx2d.fillText(`Tanggal: ${today}`, 350, 300);

    // Dummy barcode
    ctx2d.fillStyle = 'black';
    ctx2d.fillRect(350, 350, 280, 5);
    ctx2d.fillRect(360, 370, 5, 50);
    ctx2d.fillRect(375, 370, 3, 50);
    ctx2d.fillRect(385, 370, 7, 50);
    ctx2d.fillRect(400, 370, 2, 50);
    ctx2d.fillRect(415, 370, 4, 50);
    ctx2d.fillRect(430, 370, 6, 50);

    ctx2d.fillStyle = 'black';
    ctx2d.font = '22px sans-serif';
    
    const caption = `
Username       : ${username}
User ID            : ${userId}
Date                 : ${today}
THANKS TOO : ALL PARTNER
    `;

    const buffer = canvas.toBuffer('image/png');
    await bot.sendPhoto(chatId, buffer, { caption });
  } catch (err) {
    console.error('Gagal generate ID card:', err.message);
    bot.sendMessage(chatId, 'Gagal generate ID card.');
  }
});


bot.onText(/^(\.xid|\/xid)/i, async (msg) => {
  const from = msg.from;
  const chat = msg.chat;

  const name = from.first_name + (from.last_name ? ' ' + from.last_name : '');
  const userId = from.id;
  const username = from.username ? '@' + from.username : '-';
    const bokep = from.username ? '' + from.username : '-';
  const dcId = 5; // Simulasi
  const isPremium = from.is_premium ? '✓' : '✗';
  const chatId = chat.id;
  const profileLink = `t.me/${bokep}`;
  let statusText = '';

  // Ambil foto profil
  let avatar = null;
  try {
    const photo = await bot.getUserProfilePhotos(userId, { limit: 1 });
    if (photo.total_count > 0) {
      const file = await bot.getFile(photo.photos[0][0].file_id);
      const url = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;
      const res = await fetch(url);
      avatar = await loadImage(await res.buffer());
    }
  } catch (e) {
    console.error('Gagal ambil foto profil:', e.message);
  }

  // Gambar ID Card
  const canvas = createCanvas(600, 300);
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#1e1e2e';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.font = 'bold 24px Arial';
  ctx.fillStyle = '#ffcc00';
  ctx.fillText('TELEGRAM ID CARD', 200, 40);
  ctx.fillStyle = '#fff';
  ctx.font = '18px Arial';
  ctx.fillText(`Nama: ${name}`, 200, 80);
  ctx.fillText(`User ID: ${userId}`, 200, 110);
  ctx.fillText(`Username: ${username}`, 200, 140);
  ctx.fillText(`DC ID: ${dcId}`, 200, 170);
  ctx.fillText(`Premium?: ${from.is_premium ? 'Iya' : 'Tidak'}`, 200, 200);

  // Gambar foto profil
  if (avatar) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(100, 130, 60, 0, Math.PI * 2, true);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(avatar, 40, 70, 120, 120);
    ctx.restore();
  }

  const buffer = canvas.toBuffer();

  // Escape MarkdownV2 text
  const escape = (text) =>
    text
      .toString()
      .replace(/[_*[\]()~`>#+\-=|{}.!]/g, (m) => '\\' + m);

  // Caption MarkdownV2
  const caption = `
<blockquote>「 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 」
User         : ${username}
Ur ID        : ${userId}
Status      :  ${isPremium}
Chat ID     :  ${chatId} 
Locations : ${chat.title || 'Private Chat'}
Link Profil : ${profileLink}
</blockquote>
`;

  await bot.sendPhoto(chatId, buffer, {
    caption,
    parse_mode: 'HTML',
  });
});



const hasilGame = ['goal', 'save', 'miss'];
function acakHasil() {
  return hasilGame[Math.floor(Math.random() * hasilGame.length)];
}

function getEmojiHasil(status) {
  if (status === 'goal') return '⚽️🥅 GOOOLLLL!!!';
  if (status === 'save') return '🧤❌ DITEPIS KIPER!';
  return '😓❌ MELESET!';
}

const antrian = []; // antrean pemain
const skorUser = {}; // skor masing-masing user

function getDisplayName(user) {
  return user.username ? `@${user.username}` : user.first_name;
}

bot.onText(/^\/mainbola2$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!skorUser[userId]) skorUser[userId] = { goal: 0 };

  // Cek apakah user sudah dalam antrian
  if (antrian.find((u) => u.id === userId)) {
    return bot.sendMessage(chatId, '⏳ Kamu sedang menunggu lawan...');
  }

  antrian.push({ id: userId, info: msg.from });

  if (antrian.length < 2) {
    return bot.sendMessage(chatId, '🕹️ Menunggu lawan bermain... Kirim /mainbola2 dari akun lain!');
  }

  // Dapatkan dua pemain
  const player1 = antrian.shift();
  const player2 = antrian.shift();

  const hasil1 = acakHasil();
  const hasil2 = acakHasil();

  if (hasil1 === 'goal') skorUser[player1.id].goal++;
  if (!skorUser[player2.id]) skorUser[player2.id] = { goal: 0 };
  if (hasil2 === 'goal') skorUser[player2.id].goal++;

  const sent = await bot.sendMessage(chatId, `🏟️ *Pertandingan Dimulai!*\n\n⚽️ ${getDisplayName(player1.info)} vs ${getDisplayName(player2.info)}`, {
    parse_mode: 'Markdown'
  });

  const steps = [
    `👟 ${getDisplayName(player1.info)} bersiap menendang...`,
    `👤 ${getDisplayName(player1.info)}: ${getEmojiHasil(hasil1)}`,
    `🤖 Sekarang giliran ${getDisplayName(player2.info)}...`,
    `👤 ${getDisplayName(player2.info)}: ${getEmojiHasil(hasil2)}`,
    `🏆 *Skor Total:*\n${getDisplayName(player1.info)}: *${skorUser[player1.id].goal}*\n${getDisplayName(player2.info)}: *${skorUser[player2.id].goal}*\n\n_Ketik /mainbola2 untuk main lagi!_`
  ];

  for (let i = 0; i < steps.length; i++) {
    await new Promise(res => setTimeout(res, 1200));
    await bot.editMessageText(steps[i], {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: 'Markdown'
    });
  }
});



// Skor disimpan berdasarkan user ID
const CetakScore = {};

// Fungsi hasil acak
function acakHasil() {
  return Math.random() > 0.5 ? 'goal' : 'miss';
}

// Fungsi untuk menampilkan emoji sesuai hasil
function getEmojiHasil(hasil) {
  return hasil === 'goal' ? '🥅⚽️ *GOL!*' : '💨❌ *Gagal!*';
}

// Command utama /mainbola
bot.onText(/^\/mainbola$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const userHasil = acakHasil();
  const botHasil = acakHasil();

  // Inisialisasi skor jika belum ada
  if (!CetakScore[userId]) CetakScore[userId] = { user: 0, bot: 0 };

  // Update skor sesuai hasil
  if (userHasil === 'goal') CetakScore[userId].user++;
  if (botHasil === 'goal') CetakScore[userId].bot++;

  // Kirim pesan awal pertandingan
  const send = await bot.sendMessage(chatId, '🏟️ *Pertandingan dimulai!*\n\n⚽️ Kamu menendang bola...', {
    parse_mode: 'Markdown',
  });

  // Animasi pertandingan langkah demi langkah
  const step = [
    '🏃‍♂️ Bola bergerak menuju gawang...',
    `👤 Kamu: ${getEmojiHasil(userHasil)}`,
    '🤖 Bot bersiap menendang...',
    '⚽️ Bola bergerak ke arahmu...',
    `🤖 Bot: ${getEmojiHasil(botHasil)}`,
    `🏆 *Skor Sementara:*\n👤 Kamu: *${CetakScore[userId].user}* | 🤖 Bot: *${CetakScore[userId].bot}*\n\n_Ketik /mainbola untuk lanjut pertandingan!_`
  ];

  for (let i = 0; i < step.length; i++) {
    await new Promise(resolve => setTimeout(resolve, i === 1 || i === 4 ? 1500 : 1000));
    await bot.editMessageText(step[i], {
      chat_id: chatId,
      message_id: send.message_id,
      parse_mode: 'Markdown',
    });
  }
});

const { Chess } = require('chess.js');
const games2 = {}; // chatId -> game

function createBoardText(chess) {
  const board = chess.board();
  const pieces = {
    p: '♟', r: '♜', n: '♞', b: '♝', q: '♛', k: '♚',
    P: '♙', R: '♖', N: '♘', B: '♗', Q: '♕', K: '♔'
  };
  let text = '';
  for (let i = 7; i >= 0; i--) {
    text += (i + 1) + ' ';
    for (let j = 0; j < 8; j++) {
      const square = board[i][j];
      text += square ? pieces[square.color === 'w' ? square.type.toUpperCase() : square.type] + ' ' : '· ';
    }
    text += '\n';
  }
  text += '  a b c d e f g h';
  return '```\n' + text + '\n```';
}

bot.onText(/^\/catur(?:\s+@?(\w+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const from = msg.from;
  const opponentUsername = match[1];

  if (!opponentUsername) {
    return bot.sendMessage(chatId, '❌ Gunakan: /catur @username');
  }

  const members = await bot.getChatAdministrators(chatId).catch(() => []);
  const opponent = members.find(m => m.user.username?.toLowerCase() === opponentUsername.toLowerCase());

  if (!opponent) {
    return bot.sendMessage(chatId, '❌ Lawan tidak ditemukan atau bukan anggota grup.');
  }

  if (games2[chatId]) {
    return bot.sendMessage(chatId, '⚠️ Masih ada permainan yang berlangsung.');
  }

  const chess = new Chess();
  games2[chatId] = {
    chess,
    white: from,
    black: opponent.user,
    turn: 'w'
  };

  const board = createBoardText(chess);

  bot.sendMessage(chatId,
    `♟️ Pertandingan dimulai!\nPutih: @${from.username}\nHitam: @${opponent.user.username}\n\n${board}\n\n@${from.username}, giliran kamu!\nKetik contoh langkah seperti: \`e2 e4\``,
    {
      parse_mode: 'Markdown',
      reply_markup: {
        keyboard: [
          ['Lihat Papan'],
          ['Menyerah', 'Hentikan Permainan']
        ],
        resize_keyboard: true
      }
    }
  );
});

// Tangani semua pesan untuk perintah move & tombol keyboard
bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const user = msg.from;
  const text = msg.text.trim();

  const game = games2[chatId];
  if (!game) return;

  const { chess, white, black, turn } = game;

  const lowerText = text.toLowerCase();

  if (lowerText === 'lihat papan') {
    const board = createBoardText(chess);
    return bot.sendMessage(chatId, board, { parse_mode: 'Markdown' });
  }

  if (lowerText === 'menyerah') {
    const winner = user.id === white.id ? black.username : white.username;
    delete games2[chatId];
    return bot.sendMessage(chatId, `🏳️ @${user.username} menyerah. Pemenang: @${winner}`);
  }

  if (lowerText === 'hentikan permainan') {
    delete games2[chatId];
    return bot.sendMessage(chatId, '⛔ Permainan dihentikan.');
  }

  // Tangani langkah catur
  const moveMatch = text.match(/^([a-h][1-8])\s+([a-h][1-8])$/i);
  if (moveMatch) {
    const fromPos = moveMatch[1];
    const toPos = moveMatch[2];

    const isPlayerTurn =
      (turn === 'w' && user.id === white.id) ||
      (turn === 'b' && user.id === black.id);

    if (!isPlayerTurn) {
      return bot.sendMessage(chatId, '❌ Bukan giliran kamu.');
    }

    const move = chess.move({ from: fromPos, to: toPos });
    if (!move) return bot.sendMessage(chatId, '❌ Langkah tidak valid.');

    game.turn = turn === 'w' ? 'b' : 'w';
    const board = createBoardText(chess);

    let message = `${board}\n\n✅ @${user.username} memindahkan ${fromPos} ke ${toPos}.`;

    if (chess.in_checkmate()) {
      message += `\n\n🏁 Skakmat! Pemenang: @${user.username}`;
      delete games2[chatId];
    } else if (chess.in_draw()) {
      message += `\n\n🤝 Permainan berakhir seri!`;
      delete games2[chatId];
    } else {
      const next = game.turn === 'w' ? white.username : black.username;
      message += `\nGiliran @${next}`;
    }

    return bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  }
});

const sesiAsahOtak = {};

function formatSoal(data) {
  return `🧠 *Asah Otak*\n\n${data.soal}\n\nJawab langsung di bawah atau ketik *petunjuk*, *lewati*, atau *stop*.`;
}

bot.onText(/\/asahotak/, async (msg) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;

  try {
    const res = await axios.get('https://nirkyy-dev.hf.space/api/v1/asahotak');
    const data = res.data.data;

    sesiAsahOtak[fromId] = {
      soal: data.soal,
      jawaban: data.jawaban.toLowerCase(),
      petunjuk: data.petunjuk || 'Belum ada petunjuk. Ketik *lewati* untuk jawaban, atau *stop* untuk keluar.',
      skor: sesiAsahOtak[fromId]?.skor || 0
    };

    const soalText = formatSoal(data);
    bot.sendMessage(chatId, soalText, {
      parse_mode: 'Markdown',
      reply_markup: {
        keyboard: [['Petunjuk', 'Lewati', 'Stop']],
        resize_keyboard: true,
        one_time_keyboard: false
      }
    });
  } catch (e) {
    console.error('Error saat ambil soal:', e);
    bot.sendMessage(chatId, '❌ Gagal mengambil soal. Coba lagi nanti.');
  }
});

bot.on('message', async (msg) => {
  const fromId = msg.from.id;
  const text = msg.text?.toLowerCase().trim();
  const sesi = sesiAsahOtak[fromId];

  if (!text || text.startsWith('/')) return;
  if (!sesi) return;

  const chatId = msg.chat.id;

  if (text === 'stop') {
    delete sesiAsahOtak[fromId];
    return bot.sendMessage(chatId, '🛑 *Permainan Asah Otak dihentikan.* Ketik /asahotak untuk bermain lagi.', {
      parse_mode: 'Markdown',
      reply_markup: { remove_keyboard: true }
    });
  }

  if (text === 'petunjuk') {
    return bot.sendMessage(chatId, `💡 *Petunjuk:* ${sesi.petunjuk}`, { parse_mode: 'Markdown' });
  }

  if (text === 'lewati') {
    bot.sendMessage(chatId, `⏭ Soal dilewati. Jawaban tadi: *${sesi.jawaban}*`, { parse_mode: 'Markdown' });

    try {
      const res = await axios.get('https://nirkyy-dev.hf.space/api/v1/asahotak');
      const data = res.data.data;

      sesiAsahOtak[fromId] = {
        soal: data.soal,
        jawaban: data.jawaban.toLowerCase(),
        petunjuk: data.petunjuk || 'Belum ada petunjuk. Ketik *lewati* untuk jawaban, atau *stop* untuk keluar.',
        skor: sesi.skor
      };

      const soalText = formatSoal(data);
      return bot.sendMessage(chatId, soalText, {
        parse_mode: 'Markdown',
        reply_markup: {
          keyboard: [['Petunjuk', 'Lewati', 'Stop']],
          resize_keyboard: true,
          one_time_keyboard: false
        }
      });
    } catch (e) {
      console.error('Error saat ambil soal baru:', e);
      return bot.sendMessage(chatId, '❌ Gagal mengambil soal baru.');
    }
  }

  if (text === sesi.jawaban) {
    sesi.skor++;
    bot.sendMessage(chatId, `✅ *Benar!* Skormu sekarang: *${sesi.skor}*`, { parse_mode: 'Markdown' });

    try {
      const res = await axios.get('https://nirkyy-dev.hf.space/api/v1/asahotak');
      const data = res.data.data;

      sesiAsahOtak[fromId] = {
        soal: data.soal,
        jawaban: data.jawaban.toLowerCase(),
        petunjuk: data.petunjuk || 'Belum ada petunjuk. Ketik *lewati* untuk jawaban, atau *stop* untuk keluar.',
        skor: sesi.skor
      };

      const soalText = formatSoal(data);
      return bot.sendMessage(chatId, soalText, {
        parse_mode: 'Markdown',
        reply_markup: {
          keyboard: [['Petunjuk', 'Lewati', 'Stop']],
          resize_keyboard: true,
          one_time_keyboard: false
        }
      });
    } catch (e) {
      console.error('Error saat ambil soal baru setelah benar:', e);
      return bot.sendMessage(chatId, '❌ Gagal mengambil soal baru.');
    }
  } else {
    return bot.sendMessage(chatId, '❌ *Salah!* Coba lagi, atau ketik *petunjuk*.', { parse_mode: 'Markdown' });
  }
});

// Escape karakter HTML agar aman dikirim ke Telegram
function escapeHTML(text) {  
  return text  
    .replace(/&/g, '&amp;')  
    .replace(/</g, '&lt;')  
    .replace(/>/g, '&gt;');  
}  
  
bot.onText(/^\/gpt(?:\s+(.+))?$/, async (msg, match) => {  
  const chatId = msg.chat.id;  
  const argText = match[1]?.trim();  
  const replyText = msg.reply_to_message?.text?.trim();  
  const input = argText || replyText;  
  
  if (!input) {  
    return bot.sendMessage(chatId, '❌ Kirim prompt setelah /gpt atau balas pesan teks dengan command ini.');  
  }  
  
  try {  
    // Kirim pesan loading  
    const loadingMsg = await bot.sendMessage(chatId, '🤖 Sedang memproses jawaban, mohon tunggu sebentar...');  
  
    // Ganti URL API ke endpoint baru
    const apiUrl = `https://apidl.asepharyana.cloud/api/ai/chatgpt?text=${encodeURIComponent(input)}&prompt=&session=`;  
    const res = await axios.get(apiUrl);  
    const result = res.data;  
  
    // Hapus pesan loading  
    await bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});  
  
    if (result?.result) {  
      const safeText = escapeHTML(result.result);  
      return bot.sendMessage(chatId, `🤖 <b>GPT menjawab:</b>\n\n${safeText}`, {  
        parse_mode: 'HTML'  
      });  
    } else {  
      return bot.sendMessage(chatId, '⚠️ Gagal mendapatkan jawaban dari GPT.');  
    }  
  } catch (err) {  
    console.error('Error:', err.message);  
    return bot.sendMessage(chatId, '🚫 Terjadi kesalahan saat memproses permintaan.');  
  }  
});

bot.onText(/^\/(ai|openai)(\s+.+)?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[2]?.trim();

  if (!text) {
    return bot.sendMessage(chatId, 'Contoh: /ai siapa presiden indonesia');
  }

  await bot.sendMessage(chatId, 'Tunggu sebentar...');

  try {
    const res = await fetch(`https://fastrestapis.fasturl.cloud/aillm/gpt-4o-turbo?ask=${encodeURIComponent(text)}`);
    const data = await res.json();

    if (!data.status) {
      return bot.sendMessage(chatId, JSON.stringify(data, null, 2));
    }

    const replyText = `*© AI - Asistent New Latest*\n\n${data.result}`;
    await bot.sendMessage(chatId, replyText, { parse_mode: 'Markdown' });
  } catch (err) {
    console.error("AI Command Error:", err);
    bot.sendMessage(chatId, 'Terjadi kesalahan saat menghubungi AI.');
  }
});


const { fileTypeFromBuffer } = require("file-type");

bot.onText(/^\/qc$/, async (msg) => {
  const chatId = msg.chat.id;

  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, "❌ Kamu harus reply pesan orang lain untuk membuat quote.");
  }

  const replyMsg = msg.reply_to_message;
  const text = replyMsg.text || replyMsg.caption;

  if (!text) {
    return bot.sendMessage(chatId, "❌ Pesan yang direply tidak punya teks.");
  }

  const name = replyMsg.from.first_name || "Tanpa Nama";
  const warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"];
  const username = replyMsg.from.username || "bot";
  const ppuser = `https://t.me/i/userpic/320/${username}.jpg`;

  const obj = {
    type: "quote",
    format: "png",
    backgroundColor: warna[Math.floor(Math.random() * warna.length)],
    width: 512,
    height: 768,
    scale: 2,
    messages: [{
      entities: [],
      avatar: true,
      from: {
        id: 1,
        name,
        photo: { url: ppuser }
      },
      text,
      replyMessage: {}
    }]
  };

  try {
    const res = await axios.post("https://bot.lyo.su/quote/generate", obj, {
      headers: { "Content-Type": "application/json" }
    });

    const buffer = Buffer.from(res.data.result.image, "base64");
    const fileType = await fileTypeFromBuffer(buffer);

    if (!fileType || fileType.mime !== "image/png") {
      return bot.sendMessage(chatId, "❌ Format gambar tidak valid.");
    }

    await bot.sendSticker(chatId, buffer);
  } catch (err) {
    console.error("❌ Gagal kirim stiker brat:", err.message);
    bot.sendMessage(chatId, "❌ Gagal bikin stikernya bre.");
  }
});

bot.onText(/^\/brat(?: (.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const argsRaw = match[1];

  if (!argsRaw) {
    return bot.sendMessage(chatId, 'Gunakan: /brat <teks> [--gif] [--delay=500]');
  }

  try {
    const args = argsRaw.split(' ');

    const textParts = [];
    let isAnimated = false;
    let delay = 500;

    for (let arg of args) {
      if (arg === '--gif') isAnimated = true;
      else if (arg.startsWith('--delay=')) {
        const val = parseInt(arg.split('=')[1]);
        if (!isNaN(val)) delay = val;
      } else {
        textParts.push(arg);
      }
    }

    const text = textParts.join(' ');
    if (!text) {
      return bot.sendMessage(chatId, 'Teks tidak boleh kosong!');
    }

    // Validasi delay
    if (isAnimated && (delay < 100 || delay > 1500)) {
      return bot.sendMessage(chatId, 'Delay harus antara 100–1500 ms.');
    }

    await bot.sendMessage(chatId, '🌿 Generating stiker brat...');

    const apiUrl = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}&isAnimated=${isAnimated}&delay=${delay}`;
    const response = await axios.get(apiUrl, {
      responseType: 'arraybuffer',
    });

    const buffer = Buffer.from(response.data);

    // Kirim sticker (bot API auto-detects WebP/GIF)
    await bot.sendSticker(chatId, buffer);
  } catch (error) {
    console.error('❌ Error brat:', error.message);
    bot.sendMessage(chatId, 'Gagal membuat stiker brat. Coba lagi nanti ya!');
  }
});

const { translate } = require('bing-translate-api');

bot.onText(/^\/(?:tr|translate)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;

  const args = match[1]?.split(' ') || [];
  const lang = args[0];
  const textArg = args.slice(1).join(' ').trim();
  const replyText = msg.reply_to_message?.text?.trim();
  const msgToTranslate = replyText || textArg;

  const helpText = `
📌 Contoh penggunaan:
/translate <kode_bahasa> <teks>
/translate id Hello how are you

📚 Daftar kode bahasa:
https://cloud.google.com/translate/docs/languages
`.trim();

  if (!lang || !msgToTranslate) {
    return bot.sendMessage(chatId, helpText);
  }

  await bot.sendMessage(chatId, '⏳ Sedang menerjemahkan...');

  try {
    const result = await translate(msgToTranslate, null, lang);
    const translation = result?.translation || '⚠️ Tidak ada hasil terjemahan.';
    return bot.sendMessage(chatId, `📤 Hasil terjemahan:\n\`\`\`\n${translation}\n\`\`\``, {
      parse_mode: 'Markdown'
    });
  } catch (err) {
    console.error(err);
    return bot.sendMessage(chatId, `❌ Gagal menerjemahkan: ${err.message}`);
  }
});


bot.onText(/^\/fixcodeerror(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const errorDescription = match[1]?.trim();

  if (!errorDescription) {
    return bot.sendMessage(chatId, "❌ Kirim dengan format:\n/fixcodeerror <error nya apa>\nLalu reply dengan kode JS yang mau diperbaiki.");
  }

  const reply = msg.reply_to_message;
  if (!reply || (!reply.text && !reply.document)) {
    return bot.sendMessage(chatId, "❌ Lu harus reply ke pesan yang isinya kode JavaScript-nya bre.");
  }

  try {
    let code = "";

    if (reply.document) {
      const file = await bot.getFile(reply.document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;
      const res = await axios.get(fileUrl);
      code = res.data;
    } else {
      code = reply.text;
    }

    const prompt = `
Lu fixin kode ini bre. Error-nya udah dikasih tau.

1. Fokus ke error: ${errorDescription}
2. Jangan banyak bacot, kasih langsung kode yang udah dibenerin
3. Bungkus pake \`\`\`javascript biar bisa langsung disalin
4. kalo ada variabel undefined tambahin aja

Kode error-nya:
${code}

Langsung beresin bre, jangan nambahin omongan.
`;

    const { data } = await axios.get("https://fastrestapis.fasturl.cloud/aillm/gpt-4o", {
      params: { ask: prompt },
      headers: { accept: "application/json" }
    });

    if (!data || !data.result) {
      return bot.sendMessage(chatId, "❌ Gagal dapet respon dari AI bre.");
    }

    let result = data.result.trim();

    // Tambahkan backtick kalau belum ada
    if (!result.includes("```")) {
      result = `\`\`\`javascript\n${result}\n\`\`\``;
    }

    return bot.sendMessage(chatId, result.length > 4000 ? result.slice(0, 4000) + "..." : result, {
      parse_mode: "Markdown"
    });
  } catch (err) {
    console.error("FixCodeError Error:", err);
    return bot.sendMessage(chatId, "❌ Ada error bre pas proses fix kode.");
  }
});

bot.onText(/^\/fixcode$/, async (msg) => {
  const chatId = msg.chat.id;

  try {
    let code = null;

    // Ambil dari balasan teks
    if (msg.reply_to_message?.text) {
      code = msg.reply_to_message.text;
    }

    // Atau ambil dari file .js
    else if (msg.reply_to_message?.document) {
      const doc = msg.reply_to_message.document;
      if (
        doc.mime_type === "application/javascript" ||
        doc.file_name.endsWith(".js")
      ) {
        const file = await bot.getFile(doc.file_id);
        const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;
        const res = await fetch(fileUrl);
        code = await res.text();
      }
    }

    if (!code) {
      return bot.sendMessage(chatId, "❌ Balas pesan teks error atau file .js dulu bre.");
    }

    await bot.sendMessage(chatId, "🧠 Otw gua bantu benerin kodenya ya bre...");

    const prompt = "kamu adalah ai yang bisa perbaiki code yang error";
    const content = `
Lu adalah AI expert dalam memperbaiki semua kode pemrograman (seperti JavaScript, Python, C++, dll). Tugas lu:

1. Perbaiki kode yang error atau bermasalah tanpa penjelasan tambahan.
2. Langsung tulis ulang kodenya yang sudah diperbaiki.
3. Jangan kasih penjelasan, cukup kirim kodenya aja.

4. Kasih hasilnya pake format \`\`\`(bahasa pemograman) di awal dan \`\`\` di akhir biar gua gampang salin.

Ini kodenya bre:

${code}
`;

    const apiUrl = `https://api.siputzx.my.id/api/ai/gpt3?prompt=${encodeURIComponent(prompt)}&content=${encodeURIComponent(content)}`;
    const response = await fetch(apiUrl);
    const data = await response.json();

    if (data?.result) {
      let reply = data.result.trim();

      // Bungkus kalau belum pakai backtick
      if (!reply.includes("```")) {
        reply = `\`\`\`javascript\n${reply}\n\`\`\``;
      }

      return bot.sendMessage(chatId, reply.length > 4000 ? reply.slice(0, 4000) + "..." : reply, {
        parse_mode: "Markdown",
      });
    } else {
      return bot.sendMessage(chatId,"❌ Gagal dapet balasan dari AI bre.");
    }
  } catch (err) {
    console.error("FixCode Error:", err);
    return bot.sendMessage(chatId, "❌ Terjadi error pas proses perbaikan kode.");
  }
});

const AdmZip = require("adm-zip");

bot.onText(/^\/fixcode2$/, async (msg) => {
  const chatId = msg.chat.id;

  try {
    let code = null;

    if (!msg.reply_to_message) {
      return bot.sendMessage(chatId, "❌ Balas pesan teks atau file `.js` / `.zip` dulu bre.");
    }

    // Ambil dari balasan teks
    if (msg.reply_to_message.text) {
      code = msg.reply_to_message.text;
    }

    // Ambil dari dokumen
    else if (msg.reply_to_message.document) {
      const doc = msg.reply_to_message.document;
      const file = await bot.getFile(doc.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;
      const res = await fetch(fileUrl);
      const buffer = await res.buffer();

      // Kalau .js langsung parse
      if (
        doc.mime_type === "application/javascript" ||
        doc.file_name.endsWith(".js")
      ) {
        code = buffer.toString();
      }

      // Kalau .zip => ekstrak dan cari file .js
      else if (
        doc.mime_type === "application/zip" ||
        doc.file_name.endsWith(".zip")
      ) {
        const zip = new AdmZip(buffer);
        const zipEntries = zip.getEntries();

        const jsEntry = zipEntries.find(entry =>
          entry.entryName.endsWith(".js") && !entry.isDirectory
        );

        if (!jsEntry) {
          return bot.sendMessage(chatId, "❌ Gak nemu file `.js` di dalam ZIP-nya bre.");
        }

        code = zip.readAsText(jsEntry);
      }
    }

    if (!code) {
      return bot.sendMessage(chatId, "❌ Gagal ambil kode dari balasan bro.");
    }

    await bot.sendMessage(chatId, "🧠 Otw gua bantu benerin kodenya ya bre...");

    const prompt = `
Lu adalah AI expert dalam memperbaiki semua kode pemrograman (seperti JavaScript, Python, C++, dll). Tugas lu:

1. Perbaiki kode yang error atau bermasalah tanpa penjelasan tambahan.
2. Langsung tulis ulang kodenya yang sudah diperbaiki.
3. Jangan kasih penjelasan, cukup kirim kodenya aja.
4. Kasih hasilnya pake format \`\`\`(bahasa pemograman) di awal dan \`\`\` di akhir biar gua gampang salin.

Ini kodenya bre:

${code}
`;

    const url = `https://fastrestapis.fasturl.cloud/aillm/gpt-4o?ask=${encodeURIComponent(prompt)}`;
    const response = await fetch(url);
    const data = await response.json();

    if (data?.result) {
      let reply = data.result.trim();

      if (!reply.includes("```")) {
        reply = `\`\`\`javascript\n${reply}\n\`\`\``;
      }

      return bot.sendMessage(chatId, reply.length > 4000 ? reply.slice(0, 4000) + "..." : reply, {
        parse_mode: "Markdown",
      });
    } else {
      return bot.sendMessage(chatId, "❌ Gagal dapet balasan dari AI bre.");
    }
  } catch (err) {
    console.error("FixCode Error:", err);
    return bot.sendMessage(chatId, "❌ Terjadi error pas proses,lagi ada perbaikan kode.");
  }
});

bot.onText(/\/editcode(?: (.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userInput = match[1];

  if (!userInput) {
    return bot.sendMessage(chatId, '⚠️ Contoh: /editcode tambahkan audio dengan url ini https://...');
  }

  let code = null;

  try {
    // Cek jika balasan pesan teks
    if (msg.reply_to_message?.text) {
      code = msg.reply_to_message.text;
    }

    // Cek jika balasan adalah file JS
    else if (msg.reply_to_message?.document) {
      const doc = msg.reply_to_message.document;
      const mimeType = doc.mime_type;
      const fileName = doc.file_name;

      if (mimeType === 'application/javascript' || fileName.endsWith('.js')) {
        const file = await bot.getFile(doc.file_id);
        const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;

        const res = await fetch(fileUrl);
        code = await res.text();
      }
    }

    if (!code) {
      return bot.sendMessage(chatId, '❌ Balas pesan teks atau file .js dulu bre.');
    }

    await bot.sendMessage(chatId, '🧠 Otw gua edit kodenya sesuai perintah lu...');

    const prompt = `
Lu adalah AI expert coding. Gua punya satu file script yang pengen gua ubah.

Tugas lu:
1. Ubah kodenya sesuai perintah gua.
2. Jangan kasih penjelasan tambahan.
3. Langsung kirim hasil akhir dalam format \`\`\`javascript

Perintah edit:
${userInput}

Kodenya:
${code}
`;

    const url = `https://fastrestapis.fasturl.cloud/aillm/gpt-4o?ask=${encodeURIComponent(prompt)}`;
    const response = await fetch(url);
    const data = await response.json();

    if (data?.result) {
      let reply = data.result.trim();
      const finalCode = reply.includes("```") ? reply : `\`\`\`javascript\n${reply}\n\`\`\``;

      if (finalCode.length > 4000) {
        // Jika terlalu panjang, potong pesan
        return bot.sendMessage(chatId, finalCode.slice(0, 4000) + '...', {
          parse_mode: 'Markdown',
        });
      }

      return bot.sendMessage(chatId, finalCode, { parse_mode: 'Markdown' });
    } else {
      return bot.sendMessage(chatId, '❌ Gagal dapet respon dari AI bre.');
    }
  } catch (err) {
    console.error('CodeEdit Error:', err);
    return bot.sendMessage(chatId, '❌ Terjadi error pas edit kode.');
  }
});

bot.onText(/\/mediafire (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[1];

  try {
    if (!url) {
      return bot.sendMessage(chatId, "🚫 Masukkan link MediaFire!\nContoh: /mediafire https://www.mediafire.com/file/xxx/file.zip");
    }

    const res = await axios.get("https://fastrestapis.fasturl.cloud/downup/mediafiredown", {
      params: { url },
      headers: { "accept": "application/json" }
    });

    const data = res.data.result;
    if (!data || !data.download) {
      return bot.sendMessage(chatId, "❌ Gagal mendapatkan data file. Pastikan link MediaFire valid.");
    }

    const caption = `📁 ${data.filename}*
Ukuran: ${data.size}
Tipe: ${data.filetype}
Upload: ${new Date(data.created).toLocaleString()}
Uploader: ${data.owner || "Tidak diketahui"}
🔗 [Download Langsung](${data.download})`;

    bot.sendDocument(chatId, data.download, {
      caption,
      parse_mode: "Markdown"
    });

  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat mengunduh file.");
  }
});

bot.onText(/^\/nulis(?: (.+))?/, async (msg, match) => {
  if (!enabled) return;

  const chatId = msg.chat.id;
  const text = match[1];

  if (!text) {
    return bot.sendMessage(
      chatId,
      "Mau nulis apa? Contoh:\n/nulis aku sayang kamu"
    );
  }

  try {
    const response = await axios.post(
      "https://lemon-write.vercel.app/api/generate-book",
      {
        text,
        font: "default",
        color: "#000000",
        size: "32",
      },
      {
        responseType: "arraybuffer",
        headers: { "Content-Type": "application/json" },
      }
    );

    await bot.sendPhoto(chatId, Buffer.from(response.data));
  } catch (error) {
    console.error("Nulis error:", error.message);
    bot.sendMessage(chatId, "❌ Error, coba lagi nanti ya.");
  }
});

// Fungsi untuk mengaktifkan/menonaktifkan plugin
module.exports = {
  enable() {
    enabled = true;
    console.log("[PLUGIN] Nulis diaktifkan");
  },
  disable() {
    enabled = false;
    console.log("[PLUGIN] Nulis dinonaktifkan");
  },
};

bot.onText(/^\/play(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const query = match[1];

  if (!query) {
    return bot.sendMessage(chatId, 'Kirim judul lagu setelah perintah.\n\nContoh: `/play akhir tak bahagia`', {
      parse_mode: 'Markdown'
    });
  }

  try {
    await bot.sendMessage(chatId, '🔎 Sedang mencari lagu...');

    const url = `https://api.fasturl.link/downup/ytdown-v1?name=${encodeURIComponent(query)}&format=mp3&quality=320&server=auto`;
    const response = await axios.get(url, {
      headers: {
        'accept': 'application/json'
      }
    });

    const res = response.data;

    if (res.status !== 200 || !res.result || !res.result.media) {
      return bot.sendMessage(chatId, '❌ Gagal mendapatkan lagu. Coba lagi dengan judul yang berbeda.');
    }

    const {
      title,
      media,
      url: ytUrl,
      metadata,
      author
    } = res.result;

    const thumbUrl = metadata.thumbnail;
    const tempThumbPath = path.join(__dirname, `thumb-${Date.now()}.jpg`);

    // Download thumbnail
    const thumbRes = await fetch(thumbUrl);
    const thumbBuffer = await thumbRes.arrayBuffer();
    fs.writeFileSync(tempThumbPath, Buffer.from(thumbBuffer));

    // Kirim info lagu
    await bot.sendPhoto(chatId, thumbUrl, {
      caption: `🎶 *${title}*\n👤 *${author.name}*\n🕒 *${metadata.duration}*\n📺 [Tonton di YouTube](${ytUrl})\n\nSedang mengirim audionya...`,
      parse_mode: 'Markdown'
    });

    // Kirim audio
    await bot.sendAudio(chatId, media, {
      title: title,
      performer: author.name,
      thumb: tempThumbPath
    }, {
      filename: `${title}.mp3`,
      contentType: 'audio/mpeg'
    });

    // Hapus thumbnail sementara
    fs.unlinkSync(tempThumbPath);

  } catch (err) {
    console.error('Error /play:', err);
    bot.sendMessage(chatId, '🚫 Terjadi kesalahan saat mengambil lagu.');
  }
});

function isPremium(userId) {
  return false; // sesuaikan dengan logika premium kamu
}

bot.onText(/^\/done(?:\s+(.+))?$/, async (msg, match) => {
  const userId = msg.from.id;
  const input = match[1];

  if (!isPremium(userId) && !isOwner(userId)) {
    return bot.sendMessage(msg.chat.id, "❌ Perintah ini hanya untuk *premium user* atau *owner*.", {
      parse_mode: "Markdown",
    });
  }

  if (!input) {
    return bot.sendMessage(
      msg.chat.id,
      "📌 *Gunakan format yang benar!*\n\nContoh:\n/done jasa install panel,15000,Dana",
      { parse_mode: "Markdown" }
    );
  }

  const [namaBarang, hargaBarang, metodeBayar] = input.split(",").map(part => part?.trim());
  if (!namaBarang || !hargaBarang) {
    return bot.sendMessage(
      msg.chat.id,
      "❗ Format salah. Minimal harus ada *nama barang* dan *harga*.\nContoh:\n/done jasa install panel,15000,Dana",
      { parse_mode: "Markdown" }
    );
  }

  const hargaFormatted = `Rp${Number(hargaBarang).toLocaleString("id-ID")}`;
  const metodePembayaran = metodeBayar || "Tidak disebutkan";
  const now = new Date().toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  bot.sendPhoto(msg.chat.id, "https://files.catbox.moe/05scm5.jpg", {
    caption: 
`✅ Transaksi Selesai\n\n📦 barang ${namaBarang}\n💳 Harga: ${hargaFormatted}\n💰 Pembayaran: ${metodePembayaran}\n⏰ waktu ${now}`,
       parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "📌 Testimoni", url: config.linkSaluran }, { text: "🛒 Marketplace", url: config.linkGrup }],
      ]
    }
  });
});


// Fungsi komentar berdasarkan nilai
function komentarTampan(nilai) {
  if (nilai >= 100) return "💎 Ganteng dewa, mustahil diciptakan ulang.";
  if (nilai >= 94) return "🔥 Ganteng gila! Mirip artis Korea!";
  if (nilai >= 90) return "😎 Bintang iklan skincare!";
  if (nilai >= 83) return "✨ Wajahmu memantulkan sinar kebahagiaan.";
  if (nilai >= 78) return "🧼 Bersih dan rapih, cocok jadi influencer!";
  if (nilai >= 73) return "🆒 Ganteng natural, no filter!";
  if (nilai >= 68) return "😉 Banyak yang naksir nih kayaknya.";
  if (nilai >= 54) return "🙂 Lumayan sih... asal jangan senyum terus.";
  if (nilai >= 50) return "😐 Gantengnya malu-malu.";
  if (nilai >= 45) return "😬 Masih bisa lah asal percaya diri.";
  if (nilai >= 35) return "🤔 Hmm... mungkin bukan harinya.";
  if (nilai >= 30) return "🫥 Sedikit upgrade skincare boleh tuh.";
  if (nilai >= 20) return "🫣 Coba pose dari sudut lain?";
  if (nilai >= 10) return "😭 Yang penting akhlaknya ya...";
  return "😵 Gagal di wajah, semoga menang di hati.";
}

function komentarCantik(nilai) {
  if (nilai >= 100) return "👑 Cantiknya level dewi Olympus!";
  if (nilai >= 94) return "🌟 Glowing parah! Bikin semua iri!";
  if (nilai >= 90) return "💃 Jalan aja kayak jalan di runway!";
  if (nilai >= 83) return "✨ Inner & outer beauty combo!";
  if (nilai >= 78) return "💅 Cantik ala aesthetic tiktok!";
  if (nilai >= 73) return "😊 Manis dan mempesona!";
  if (nilai >= 68) return "😍 Bisa jadi idol nih!";
  if (nilai >= 54) return "😌 Cantik-cantik adem.";
  if (nilai >= 50) return "😐 Masih oke, tapi bisa lebih wow.";
  if (nilai >= 45) return "😬 Coba lighting lebih terang deh.";
  if (nilai >= 35) return "🤔 Unik sih... kayak seni modern.";
  if (nilai >= 30) return "🫥 Banyak yang lebih butuh makeup.";
  if (nilai >= 20) return "🫣 Mungkin inner beauty aja ya.";
  if (nilai >= 10) return "😭 Cinta itu buta kok.";
  return "😵 Semoga kamu lucu pas bayi.";
}

// /cektampan
bot.onText(/^\/cektampan$/, (msg) => {
  const nilai = [10, 20, 30, 35, 45, 50, 54, 68, 73, 78, 83, 90, 94, 100][Math.floor(Math.random() * 14)];
  const teks = `
📊 *Hasil Tes Ketampanan*
👤 Nama: *${msg.from.first_name}*
💯 Nilai: *${nilai}%*
🗣️ Komentar: ${komentarTampan(nilai)}
  `.trim();

  bot.sendMessage(msg.chat.id, teks, { parse_mode: 'Markdown' });
});

// /cekcantik
bot.onText(/^\/cekcantik$/, (msg) => {
  const nilai = [10, 20, 30, 35, 45, 50, 54, 68, 73, 78, 83, 90, 94, 100][Math.floor(Math.random() * 14)];
  const teks = `
📊 *Hasil Tes Kecantikan*
👤 Nama: *${msg.from.first_name}*
💯 Nilai: *${nilai}%*
🗣️ Komentar: ${komentarCantik(nilai)}
  `.trim();

  bot.sendMessage(msg.chat.id, teks, { parse_mode: 'Markdown' });
});

// Nilai dan komentar untuk kekayaan
function komentarKaya(nilai) {
  if (nilai >= 100) return "💎 Sultan auto endorse siapa aja.";
  if (nilai >= 90) return "🛥️ Jet pribadi parkir di halaman rumah.";
  if (nilai >= 80) return "🏰 Rumahnya bisa buat konser.";
  if (nilai >= 70) return "💼 Bos besar! Duit ngalir terus.";
  if (nilai >= 60) return "🤑 Kaya banget, no debat.";
  if (nilai >= 50) return "💸 Kaya, tapi masih waras.";
  if (nilai >= 40) return "💳 Lumayan lah, saldo aman.";
  if (nilai >= 30) return "🏦 Kayanya sih... dari tampang.";
  if (nilai >= 20) return "🤔 Cukup buat traktir kopi.";
  if (nilai >= 10) return "🫠 Kaya hati, bukan dompet.";
  return "🙃 Duitnya imajinasi aja kayaknya.";
}

// Nilai dan komentar untuk kemiskinan
function komentarMiskin(nilai) {
  if (nilai >= 100) return "💀 Miskin absolut, utang warisan.";
  if (nilai >= 90) return "🥹 Mau beli gorengan mikir 3x.";
  if (nilai >= 80) return "😩 Isi dompet: angin & harapan.";
  if (nilai >= 70) return "😭 Bayar parkir aja utang.";
  if (nilai >= 60) return "🫥 Pernah beli pulsa receh?";
  if (nilai >= 50) return "😬 Makan indomie aja dibagi dua.";
  if (nilai >= 40) return "😅 Listrik token 5 ribu doang.";
  if (nilai >= 30) return "😔 Sering nanya *gratis ga nih?*";
  if (nilai >= 20) return "🫣 Semoga dapet bansos.";
  if (nilai >= 10) return "🥲 Yang penting hidup.";
  return "😵 Gaji = 0, tagihan = tak terbatas.";
}

// /cekkaya
bot.onText(/^\/cekkaya$/, (msg) => {
  const nilai = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100][Math.floor(Math.random() * 10)];
  const teks = `
💵 *Tes Kekayaan*
👤 Nama: *${msg.from.first_name}*
💰 Nilai: *${nilai}%*
🗣️ Komentar: ${komentarKaya(nilai)}
  `.trim();

  bot.sendMessage(msg.chat.id, teks, { parse_mode: 'Markdown' });
});

// /cekmiskin
bot.onText(/^\/cekmiskin$/, (msg) => {
  const nilai = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100][Math.floor(Math.random() * 10)];
  const teks = `
📉 *Tes Kemiskinan*
👤 Nama: *${msg.from.first_name}*
📉 Nilai: *${nilai}%*
🗣️ Komentar: ${komentarMiskin(nilai)}
  `.trim();

  bot.sendMessage(msg.chat.id, teks, { parse_mode: 'Markdown' });
});

// Fungsi komentar berdasarkan skor
function komentarJanda(nilai) {
  if (nilai >= 100) return "🔥 Janda premium, banyak yang ngantri.";
  if (nilai >= 90) return "💋 Bekas tapi masih segel.";
  if (nilai >= 80) return "🛵 Banyak yang ngajak balikan.";
  if (nilai >= 70) return "🌶️ Janda beranak dua, laku keras.";
  if (nilai >= 60) return "🧕 Pernah disakiti, sekarang bersinar.";
  if (nilai >= 50) return "🪞 Masih suka upload status galau.";
  if (nilai >= 40) return "🧍‍♀️ Janda low-profile.";
  if (nilai >= 30) return "💔 Ditinggal pas lagi sayang-sayangnya.";
  if (nilai >= 20) return "🫥 Baru ditinggal, masih labil.";
  if (nilai >= 10) return "🥲 Janda lokal, perlu support moral.";
  return "🚫 Masih istri orang, bro.";
}

// /cekjanda
bot.onText(/^\/cekjanda$/, (msg) => {
  const nilai = Math.floor(Math.random() * 101); // 0 - 100
  const teks = `
👠 *Tes Kejandaan*
👤 Nama: *${msg.from.first_name}*
📊 Nilai: *${nilai}%*
🗣️ Komentar: ${komentarJanda(nilai)}
  `.trim();

  bot.sendMessage(msg.chat.id, teks, { parse_mode: 'Markdown' });
});

// Fungsi komentar sesuai skor pacar
function komentarPacar(nilai) {
  if (nilai >= 95) return "💍 Sudah tunangan, tinggal nikah.";
  if (nilai >= 85) return "❤️ Pacaran sehat, udah 3 tahun lebih.";
  if (nilai >= 70) return "😍 Lagi anget-angetnya.";
  if (nilai >= 60) return "😘 Sering video call tiap malam.";
  if (nilai >= 50) return "🫶 Saling sayang, tapi LDR.";
  if (nilai >= 40) return "😶 Dibilang pacaran, belum tentu. Tapi dibilang nggak, juga iya.";
  if (nilai >= 30) return "😅 Masih PDKT, nunggu sinyal.";
  if (nilai >= 20) return "🥲 Sering ngechat, tapi dicuekin.";
  if (nilai >= 10) return "🫠 Naksir diam-diam.";
  return "❌ Jomblo murni, nggak ada harapan sementara ini.";
}

// Command /cekpacar
bot.onText(/^\/cekpacar$/, (msg) => {
  const nilai = Math.floor(Math.random() * 101); // nilai 0-100
  const teks = `
💕 *Tes Kepacaran*
👤 Nama: *${msg.from.first_name}*
📊 Nilai: *${nilai}%*
🗣️ Komentar: ${komentarPacar(nilai)}
  `.trim();

  bot.sendMessage(msg.chat.id, teks, { parse_mode: 'Markdown' });
});

bot.onText(/^\/cekkhodam(?: (.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const nama = (match[1] || '').trim();

  if (!nama) {
    return bot.sendMessage(chatId, 'ɴᴀᴍᴀɴʏᴀ ᴍᴀɴᴀ ᴀɴᴊᴇɴɢ🤓');
  }

  const khodamList = [
    'si ganteng',
    'si jelek',
    'anomali bt script',
    'kang hapus sumber',
    'kang ngocok',
    'Anomali maklu',
    'orang gila',
    'anak rajin',
    'anak cerdas',
    'lonte gurun',
    'dugong',
    'macan yatim',
    'buaya darat',
    'kanjut terbang',
    'kuda kayang',
    'janda salto',
    'lonte alas',
    'jembut singa',
    'gajah terbang',
    'kuda cacat',
    'jembut pink',
    'sabun bolong',
    'ambalambu',
    'megawati',
    'jokowi'
  ];

  const pickRandom = (list) => list[Math.floor(Math.random() * list.length)];

  const hasil = `
<blockquote><b>𖤐 ʜᴀsɪʟ ᴄᴇᴋ ᴋʜᴏᴅᴀᴍ:</b>
╭───────────────────
├ •ɴᴀᴍᴀ : ${nama}
├ •ᴋʜᴏᴅᴀᴍɴʏᴀ : ${pickRandom(khodamList)}
├ •ɴɢᴇʀɪ ʙᴇᴛ ᴊɪʀ ᴋʜᴏᴅᴀᴍɴʏᴀ
╰───────────────────
<b>ɴᴇxᴛ ᴄᴇᴋ ᴋʜᴏᴅᴀᴍɴʏᴀ sɪᴀᴘᴀ ʟᴀɢɪ.</b>
</blockquote>
  `;

  bot.sendMessage(chatId, hasil, { parse_mode: 'HTML' });
});

bot.onText(/^\/script$/, (msg) => {
  const chatId = msg.chat.id;

  const caption = `
<blockquote><b> NAME      : ZeroTwo-MD</b>
 <b>PRICE      : 50K FULL UPDATE</b>
 <b>FITUR      : SUNG CHAT OWNER</b>
 <b>BENEFIT : GET NO ENC + PT SC</b>
</blockquote>
`;

  bot.sendPhoto(chatId, 'https://files.catbox.moe/538smi.jpg', {
    caption,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '𝙾𝚠𝚗𝚎𝚛', url: 'https://t.me/xlilnyx' }
        ]
      ]
    }
  });
});

const cooldowns = new Map(); // Untuk cooldown per user
const COOLDOWN_DURATION = 10000; // 10 detik

const urls = {
  tebakkata: 'https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json',
  tebakkalimat: 'https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkalimat.json',
  tebaktebakan: 'https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaktebakan.json',
  tebakgambar: 'https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json',
  tebaklirik: 'https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json',
  tebakbendera: 'https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakbendera.json',
  tebakkabupaten: 'https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkabupaten.json',
};

async function loadSoal(type) {
  const res = await fetch(urls[type]);
  const data = await res.json();
  return data[Math.floor(Math.random() * data.length)];
}

const games = {
  tebakkata: async (chatId) => {
    const soal = await loadSoal('tebakkata');
    const jawaban = soal.jawaban.toLowerCase();
    bot.sendMessage(chatId, `🧠 *Tebak Kata!*\n\n${soal.soal}\n\nKetik jawabannya dalam 60 detik!`, { parse_mode: 'Markdown' });
    return jawaban;
  },
  tebakkalimat: async (chatId) => {
    const soal = await loadSoal('tebakkalimat');
    const jawaban = soal.jawaban.toLowerCase();
    bot.sendMessage(chatId, `🧠 *Tebak Kalimat!*\n\n${soal.soal}\n\nJawaban dalam 60 detik!`, { parse_mode: 'Markdown' });
    return jawaban;
  },
  tebaktebakan: async (chatId) => {
    const soal = await loadSoal('tebaktebakan');
    const jawaban = soal.jawaban.toLowerCase();
    bot.sendMessage(chatId, `🤔 *Tebak-Tebakan!*\n\n${soal.soal}\n\nJawaban dalam 60 detik!`, { parse_mode: 'Markdown' });
    return jawaban;
  },
  tebakgambar: async (chatId) => {
    const soal = await loadSoal('tebakgambar');
    const jawaban = soal.jawaban.toLowerCase();
    await bot.sendPhoto(chatId, soal.img, {
      caption: `🖼️ *Tebak Gambar!*\n\nJawaban dalam 60 detik...`,
      parse_mode: 'Markdown'
    });
    return jawaban;
  },
  tebaklirik: async (chatId) => {
    const soal = await loadSoal('tebaklirik');
    const jawaban = soal.jawaban.toLowerCase();
    bot.sendMessage(chatId, `🎵 *Tebak Lirik!*\n\n"${soal.soal}"\n\nJawaban dalam 60 detik...`, { parse_mode: 'Markdown' });
    return jawaban;
  },
  tebakbendera: async (chatId) => {
    const soal = await loadSoal('tebakbendera');
    const jawaban = soal.name.toLowerCase();
    await bot.sendPhoto(chatId, soal.img, {
      caption: `🏳️ *Tebak Bendera!*\n\nNegara apakah ini?`,
      parse_mode: 'Markdown'
    });
    return jawaban;
  },
  tebakkabupaten: async (chatId) => {
    const soal = await loadSoal('tebakkabupaten');
    const jawaban = soal.name.toLowerCase();
    await bot.sendPhoto(chatId, soal.img, {
      caption: `🗺️ *Tebak Kabupaten!*\n\nKabupaten apakah ini?`,
      parse_mode: 'Markdown'
    });
    return jawaban;
  },
};

// Buat handler semua command
for (const cmd in games) {
  bot.onText(new RegExp(`^/${cmd}$`), async (msg) => {
    const chatId = msg.chat.id;
    if (sessions.has(chatId)) {
      return bot.sendMessage(chatId, '⚠️ Masih ada permainan yang belum selesai di chat ini!');
    }

    const jawaban = await games[cmd](chatId);
    const timeout = setTimeout(() => {
      bot.sendMessage(chatId, `⏰ Waktu habis!\nJawaban yang benar: *${jawaban}*`, { parse_mode: 'Markdown' });
      sessions.delete(chatId);
    }, 60000);

    sessions.set(chatId, { jawaban, timeout });
  });
}

// Jawaban pengguna
bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const sesi = sessions.get(chatId);
  const text = msg.text;

  if (!sesi || !text || text.startsWith('/')) return;

  const jawabanUser = text.toLowerCase();

  if (jawabanUser === sesi.jawaban) {
    clearTimeout(sesi.timeout);
    bot.sendMessage(chatId, `✅ Benar! Jawabannya adalah *${sesi.jawaban}*`, { parse_mode: 'Markdown' });
    sessions.delete(chatId);
  } else {
    bot.sendMessage(chatId, '❌ Salah! Coba lagi...');
  }
});

// Hint, skip, leaderboard — dengan cooldown
bot.onText(/^\/(skip|hint|leaderboard)(@[\w_]+)?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const key = `${chatId}_${userId}`;
  const now = Date.now();
  const last = cooldowns.get(key) || 0;

  if (now - last < COOLDOWN_DURATION) {
    const remaining = ((COOLDOWN_DURATION - (now - last)) / 1000).toFixed(1);
    return bot.sendMessage(chatId, `⏳ Tunggu ${remaining} detik sebelum menggunakan perintah ini lagi.`);
  }
  cooldowns.set(key, now);

  const cmd = match[1];
  const sesi = sessions.get(chatId);
  if (!sesi) return bot.sendMessage(chatId, '❌ Tidak ada permainan aktif di chat ini.');

  if (cmd === 'skip') {
    clearTimeout(sesi.timeout);
    bot.sendMessage(chatId, `⏭️ Soal dilewati!\nJawaban yang benar: *${sesi.jawaban}*`, { parse_mode: 'Markdown' });
    sessions.delete(chatId);
  } else if (cmd === 'hint') {
    const hint = sesi.jawaban.replace(/[^\s]/g, '_').split('');
    // Tampilkan satu huruf acak dari jawaban
    const pos = Math.floor(Math.random() * sesi.jawaban.length);
    hint[pos] = sesi.jawaban[pos];
    bot.sendMessage(chatId, `💡 Hint: ${hint.join('')}`);
  } else if (cmd === 'leaderboard') {
    bot.sendMessage(chatId, '📊 Leaderboard belum tersedia di versi ini.');
  }
});


const groups = new Set();

// Deteksi saat bot masuk grup baru
bot.on('new_chat_members', (msg) => {
  groups.add(msg.chat.id);
});

// Deteksi saat bot keluar dari grup
bot.on('left_chat_member', (msg) => {
  groups.delete(msg.chat.id);
});

const filePath = './group_ids.json';

// 🗂️ Fungsi bantu
function loadGroupIds() {
  try {
    return JSON.parse(fs.readFileSync(filePath));
  } catch {
    return [];
  }
}

function saveGroupIds(ids) {
  fs.writeFileSync(filePath, JSON.stringify(ids, null, 2));
}

let groupIds = loadGroupIds();


// ✅ Command: Tambah grup ID
bot.onText(/^\/addgroupid (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const id = parseInt(match[1]);

  if (isNaN(id)) return bot.sendMessage(chatId, '❌ ID tidak valid.');

  if (groupIds.includes(id)) {
    return bot.sendMessage(chatId, '⚠️ ID tersebut sudah terdaftar.');
  }

  groupIds.push(id);
  saveGroupIds(groupIds);
  bot.sendMessage(chatId, `✅ Grup ID \`${id}\` berhasil ditambahkan.`, { parse_mode: 'Markdown' });
});

// ✅ Command: Hapus grup ID
bot.onText(/^\/delgroupid (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const id = parseInt(match[1]);

  if (!groupIds.includes(id)) {
    return bot.sendMessage(chatId, '⚠️ ID tidak ditemukan dalam daftar.');
  }

  groupIds = groupIds.filter(g => g !== id);
  saveGroupIds(groupIds);
  bot.sendMessage(chatId, `🗑️ Grup ID \`${id}\` berhasil dihapus.`, { parse_mode: 'Markdown' });
});

// ✅ Command: List semua ID
bot.onText(/^\/listgroupid$/, (msg) => {
  const chatId = msg.chat.id;

  if (groupIds.length === 0) {
    return bot.sendMessage(chatId, '📭 Belum ada grup yang terdaftar.');
  }

  const list = groupIds.map((id, i) => `\`${i + 1}.\` ${id}`).join('\n');
  bot.sendMessage(chatId, `📋 *Daftar Grup ID:*\n\n${list}`, { parse_mode: 'Markdown' });
});

// ✅ Command: Forward broadcast ke semua grup (dengan validasi akses)
bot.onText(/^\/cfdgroup$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const reply = msg.reply_to_message;

  // Cek akses
  if (!isPremium(userId) && !isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Perintah ini hanya untuk *premium user* atau *owner*.", {
      parse_mode: "Markdown",
    });
  }

  // Validasi reply
  if (!reply) {
    return bot.sendMessage(chatId, '⚠️ Mohon reply pesan yang ingin di-forward ke semua grup.');
  }

  // Validasi daftar grup
  if (groupIds.length === 0) {
    return bot.sendMessage(chatId, '📭 Belum ada grup yang terdaftar untuk broadcast.');
  }

  let success = 0;
  let failed = 0;

  for (let id of groupIds) {
    try {
      await bot.forwardMessage(id, chatId, reply.message_id);
      success++;
    } catch (err) {
      failed++;
      console.error(`Gagal kirim ke ${id}:`, err.description || err.message);
    }
  }

  const result = `
<blockquote>
⌭ 🎺 ʙʀᴏᴀᴅᴄᴀsᴛ ғᴏʀᴡᴀʀᴅ ᴅᴏɴᴇ
⌭ ✔️ sᴜᴄᴄᴇs ${success} ɢʀᴏᴜᴘ
⌭ ❌ ғᴀɪʟᴇᴅ ${failed} ɢʀᴏᴜᴘ
ᣃ࿈ ᴇᴛᴇʀɴᴀʟ ɢᴀʟᴀxʏ ࿈ᣄ
</blockquote>
`.trim();

  bot.sendMessage(chatId, result, { parse_mode: 'HTML' });
});


function escapeMarkdown(text) {
  return text.replace(/[_*[\]()~`>#+\-=|{}.!]/g, '\\$&');
}

bot.onText(/^\/info$/, async (msg) => {
  const chatId = msg.chat.id;

  // Harus reply pesan seseorang
  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, '⚠️ Balas pesan seseorang dengan command /info untuk melihat informasi mereka.');
  }

  const user = msg.reply_to_message.from;
  const { id, first_name, last_name, username } = user;
  const userLink = `tg://user?id=${id}`;
  let statusText = '';

  try {
    const member = await bot.getChatMember(chatId, id);
    statusText = `\n📌 Status: ${member.status}`;
  } catch (err) {
    statusText = '';
  }

  const infoMessage =
`🧾 INFO PENGGUNA
🆔 ID  : \`${id}\`
📛 Nama: ${escapeMarkdown(first_name)}${last_name ? ' ' + escapeMarkdown(last_name) : ''}
🧑‍💻 Username: ${username ? '@' + username : '-'}
🔗 Link: [Klik Disini](${userLink})${statusText}`;

  bot.sendMessage(chatId, infoMessage, {
    parse_mode: 'Markdown',
    disable_web_page_preview: true
  });
});



// Command /instagramstalk
bot.onText(/^\/instagramstalk(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];

  if (!input) {
    return bot.sendMessage(chatId, '❌ Kirim username Instagram setelah command, contoh:\n/instagramstalk google');
  }

  try {
    const response = await axios.post('https://api.siputzx.my.id/api/stalk/instagram', {
      username: input
    }, {
      headers: {
        'Content-Type': 'application/json',
        'Accept': '*/*'
      }
    });

    const data = response.data;
    if (!data.status) {
      return bot.sendMessage(chatId, '❌ Data tidak ditemukan atau username salah.');
    }

    const ig = data.data;

    const msgText = `
📸 *Instagram Profile Info*

👤 Username: ${ig.username}
👑 Full Name: ${ig.full_name}
📝 Biography: ${ig.biography || '-'}
🔗 External URL: ${ig.external_url || '-'}
📊 Followers: ${ig.followers_count.toLocaleString()}
👥 Following: ${ig.following_count.toLocaleString()}
📬 Posts: ${ig.posts_count.toLocaleString()}
🔒 Private: ${ig.is_private ? 'Yes' : 'No'}
✔️ Verified: ${ig.is_verified ? 'Yes' : 'No'}
🏢 Business Account: ${ig.is_business_account ? 'Yes' : 'No'}
`.trim();

    await bot.sendPhoto(chatId, ig.profile_pic_url, {
      caption: msgText,
      parse_mode: 'Markdown'
    });
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, '❌ Terjadi kesalahan saat mengambil data Instagram.');
  }
});

bot.onText(/^\/stalkmlbb(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];

  if (!input || !input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Contoh penggunaan:\n/stalkmlbb 106101371|2540');
  }

  const [userId, zoneId] = input.split('|').map(v => v.trim());

  if (!userId || !zoneId) {
    return bot.sendMessage(chatId, '❌ Format salah. Gunakan: /stalkmlbb userId|zoneId');
  }

  try {
    const response = await axios.get('https://fastrestapis.fasturl.cloud/stalk/mlbb', {
      params: { userId, zoneId },
      headers: {
        'accept': 'application/json'
        // Jika perlu:
        // 'x-api-key': 'APIKEYMU'
      }
    });

    const res = response.data;

    if (res.status !== 200) {
      return bot.sendMessage(chatId, `❌ ${res.content || 'Terjadi kesalahan.'}`);
    }

    const { username, region, level, rank } = res.result;

    const message = `
✨ *MLBB Stalker Result*

👤 *Username:* ${username}
🌍 *Region:* ${region}
📈 *Level:* ${level || 'N/A'}
🏆 *Rank:* ${rank || 'N/A'}
`.trim();

    bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  } catch (err) {
    if (err.response && err.response.data) {
      const res = err.response.data;
      return bot.sendMessage(chatId, `❌ ${res.content || 'Terjadi kesalahan'}\n🛠 ${res.error || 'Unknown error'}`);
    } else {
      console.error(err);
      return bot.sendMessage(chatId, '❌ Terjadi kesalahan internal saat menghubungi API.');
    }
  }
});

bot.onText(/^\/pintereststalk(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const query = match[1];

  if (!query) {
    return bot.sendMessage(chatId, '📌 Masukkan username Pinterest!\n\nContoh: `/pintereststalk dims`', {
      parse_mode: 'Markdown'
    });
  }

  await bot.sendMessage(chatId, '🔍 Mencari informasi profil...');

  try {
    const res = await axios.post("https://api.siputzx.my.id/api/stalk/pinterest", {
      q: query
    });

    const result = res.data.result;

    const caption = `📌 *Pinterest Stalker*\n\n` +
      `👤 *Username:* ${result.username}\n` +
      `📛 *Nama Lengkap:* ${result.full_name || "-"}\n` +
      `📍 *Bio:* ${result.bio || "-"}\n` +
      `📊 *Statistik:*\n` +
      `   • Pins: ${result.stats?.pins ?? 0}\n` +
      `   • Followers: ${result.stats?.followers ?? 0}\n` +
      `   • Following: ${result.stats?.following ?? 0}\n` +
      `   • Boards: ${result.stats?.boards ?? 0}\n` +
      `🔗 *Link:* [Klik di sini](${result.profile_url})`;

    await bot.sendPhoto(chatId, result.image?.original, {
      caption,
      parse_mode: 'Markdown'
    });

  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, '❌ Gagal mengambil data. Username tidak ditemukan atau server error.');
  }
});

bot.onText(/^\/threadsstalk(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const query = match[1];

  if (!query) {
    return bot.sendMessage(chatId, 'Contoh: /threadsstalk google');
  }

  await bot.sendMessage(chatId, '🔍 Sedang mencari profil Threads...');

  try {
    const res = await axios.post("https://api.siputzx.my.id/api/stalk/threads", {
      q: query,
    });

    const data = res.data?.data;
    if (!data) {
      return bot.sendMessage(chatId, '❌ Tidak ditemukan!');
    }

    const caption = `
👤 *${data.name}* [@${data.username}]
${data.is_verified ? "✅ Terverifikasi" : ""}
🆔 ID: \`${data.id}\`
📝 Bio: ${data.bio || "-"}
👥 Followers: ${data.followers?.toLocaleString() || 0}
🔗 Link: ${data.links?.[0] || "-"}
    `.trim();

    await bot.sendPhoto(chatId, data.hd_profile_picture, {
      caption,
      parse_mode: "Markdown",
    });

  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, '❌ Gagal mengambil data profil Threads.');
  }
});

bot.onText(/^\/tiktokstalk(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const username = match[1];

  if (!username) {
    return bot.sendMessage(chatId, "❌ Masukkan username TikTok!\nContoh: /tiktokstalk mrbeast");
  }

  try {
    const { data } = await axios.post("https://api.siputzx.my.id/api/stalk/tiktok", {
      username,
    });

    if (!data.status) {
      return bot.sendMessage(chatId, "❌ Gagal mengambil data TikTok.");
    }

    const user = data.data.user;
    const stats = data.data.stats;

    const caption = `
👤 *${user.nickname}* (@${user.uniqueId})
🆔 ID: \`${user.id}\`
✅ Verified: ${user.verified ? "Yes" : "No"}
📍 Region: ${user.region}
📝 Bio: ${user.signature || "-"}
📆 Dibuat: ${new Date(user.createTime * 1000).toLocaleDateString("id-ID")}

📊 *Statistik TikTok*
👥 Followers: ${stats.followerCount.toLocaleString()}
👣 Following: ${stats.followingCount.toLocaleString()}
❤️ Likes: ${stats.heart.toLocaleString()}
🎞️ Video: ${stats.videoCount.toLocaleString()}
👫 Friends: ${stats.friendCount.toLocaleString()}
    `.trim();

    await bot.sendPhoto(chatId, user.avatarLarger, {
      caption,
      parse_mode: "Markdown",
    });
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "🚫 Terjadi kesalahan saat mengambil data.");
  }
});

bot.onText(/^\/twitterstalk(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const username = match[1];

  if (!username) {
    return bot.sendMessage(chatId, "❌ Masukkan username Twitter!\nContoh: /twitterstalk siputzx");
  }

  try {
    const { data } = await axios.post("https://api.siputzx.my.id/api/stalk/twitter", {
      user: username,
    });

    if (!data.status) {
      return bot.sendMessage(chatId, "❌ Gagal mengambil data Twitter.");
    }

    const user = data.data;

    const caption = `
🐦 *${user.name}* (@${user.username})
🆔 ID: \`${user.id}\`
✅ Verified: ${user.verified ? "Yes" : "No"}
📍 Lokasi: ${user.location || "-"}
📅 Bergabung: ${new Date(user.created_at).toLocaleDateString("id-ID")}
📝 Bio: ${user.description || "-"}

📊 *Statistik*
🧵 Tweets: ${user.stats.tweets}
👥 Followers: ${user.stats.followers}
👣 Following: ${user.stats.following}
❤️ Likes: ${user.stats.likes}
🖼️ Media: ${user.stats.media}
    `.trim();

    await bot.sendPhoto(chatId, user.profile.image, {
      caption,
      parse_mode: "Markdown"
    });
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "🚫 Terjadi kesalahan saat mengambil data Twitter.");
  }
});

bot.onText(/^\/youtubestalk(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const username = match[1];

  if (!username) {
    return bot.sendMessage(chatId, "❌ Masukkan username YouTube!\nContoh: /youtubestalk siputzx");
  }

  try {
    const { data } = await axios.post("https://api.siputzx.my.id/api/stalk/youtube", {
      username,
    });

    if (!data.status) {
      return bot.sendMessage(chatId, "❌ Gagal mengambil data YouTube.");
    }

    const ch = data.data.channel;
    const videos = data.data.latest_videos;

    const caption = `
📺 *YouTube Channel Info*
👤 Username: ${ch.username}
📌 Subscriber: ${ch.subscriberCount}
🎞️ Total Video: ${ch.videoCount}
📝 Deskripsi: ${ch.description || "-"}
🔗 [Kunjungi Channel](${ch.channelUrl})
    `.trim();

    await bot.sendPhoto(chatId, ch.avatarUrl, {
      caption,
      parse_mode: "Markdown"
    });

    for (let video of videos.slice(0, 3)) {
      await bot.sendPhoto(chatId, video.thumbnail, {
        caption: `
🎬 *${video.title}*
🕒 ${video.publishedTime} | ⏱️ ${video.duration}
👁️ ${video.viewCount}
🔗 [Tonton Video](${video.videoUrl})
        `.trim(),
        parse_mode: "Markdown"
      });
    }

  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "🚫 Terjadi kesalahan saat mengambil data dari YouTube.");
  }
});

const { unlinkSync, createWriteStream } = require('fs');
const https = require('https');

// Command /stalkff
bot.onText(/^\/stalkff(?:\s+(\d+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const id = match[1];

  if (!id) {
    return bot.sendMessage(chatId, '❌ Masukin ID akun Free Fire-nya!\nContoh: /stalkff 123456789');
  }

  const proses = await bot.sendMessage(chatId, '🔍 Lagi cari data FF-nya, sabar bre...');

  try {
    const { data } = await axios.get(`https://ff.lxonfire.workers.dev/?id=${id}`);

    if (!data || !data.nickname) {
      return bot.sendMessage(chatId, '❌ Gagal menemukan data untuk ID tersebut.');
    }

    const caption = `
👤 <b>Nickname:</b> <code>${data.nickname}</code>
🌍 <b>Region:</b> <code>${data.region}</code>
🆔 <b>OpenID:</b> <code>${data.open_id}</code>
`.trim();

    const imgUrl = data.img_url;
    const fileName = `ff_${Date.now()}.jpg`;
    const filePath = path.join(__dirname, fileName);

    const writer = createWriteStream(filePath);
    https.get(imgUrl, (res) => {
      res.pipe(writer);
      writer.on('finish', async () => {
        await bot.sendPhoto(chatId, filePath, {
          caption,
          parse_mode: 'HTML',
        });
        unlinkSync(filePath);
      });
    });

    bot.deleteMessage(chatId, proses.message_id);
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, '❌ Terjadi error saat mengambil data.');
  }
});

// Command /githubstalk
bot.onText(/^\/githubstalk(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];

  if (!input) {
    return bot.sendMessage(chatId, '❌ Gunakan: /githubstalk <username>');
  }

  try {
    const response = await axios.post(
      'https://api.siputzx.my.id/api/stalk/github',
      { user: input },
      { headers: { 'Content-Type': 'application/json' } }
    );

    const data = response.data;
    if (!data.status) {
      return bot.sendMessage(chatId, '❌ User tidak ditemukan atau API error.');
    }

    const profile = data.data;

    const replyText = `
<b>GitHub Profile Info:</b>

👤 <b>Username:</b> ${profile.username}
📝 <b>Nickname:</b> ${profile.nickname || 'N/A'}
📄 <b>Bio:</b> ${profile.bio || 'N/A'}
🏢 <b>Company:</b> ${profile.company || 'N/A'}
🔗 <b>Blog:</b> ${profile.blog || 'N/A'}
📍 <b>Location:</b> ${profile.location || 'N/A'}
📧 <b>Email:</b> ${profile.email || 'N/A'}
📦 <b>Public Repos:</b> ${profile.public_repo}
📝 <b>Public Gists:</b> ${profile.public_gists}
👥 <b>Followers:</b> ${profile.followers}
👣 <b>Following:</b> ${profile.following}
🆔 <b>ID:</b> ${profile.id}
📅 <b>Created at:</b> ${new Date(profile.created_at).toLocaleDateString()}
🔗 <b>URL:</b> <a href="${profile.url}">${profile.url}</a>
`.trim();

    await bot.sendPhoto(chatId, profile.profile_pic, {
      caption: replyText,
      parse_mode: 'HTML',
    });
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, '❌ Error saat mengambil data dari API GitHub.');
  }
});


const battleSessions = {}

bot.onText(/^\/perang(@\w+)?$/, async (msg) => {
    const chatId = msg.chat.id
    const userId = msg.from.id
    const username = msg.from.username || msg.from.first_name

    if (battleSessions[chatId]) {
        return bot.sendMessage(chatId, '❗ Masih ada pertandingan berlangsung di chat ini.');
    }

    battleSessions[chatId] = {
        players: [userId],
        names: [username],
        hp: {},
        turn: null,
        started: false
    }

    battleSessions[chatId].hp[userId] = 100

    bot.sendMessage(chatId, `💥 ${username} telah menantang duel!\nKetik /gabungperang untuk ikut!`)
})

bot.onText(/^\/gabungperang(@\w+)?$/, async (msg) => {
    const chatId = msg.chat.id
    const userId = msg.from.id
    const username = msg.from.username || msg.from.first_name

    const session = battleSessions[chatId]
    if (!session || session.players.length >= 2) {
        return bot.sendMessage(chatId, '❌ Tidak ada sesi perang terbuka atau sudah penuh.');
    }
    if (session.players.includes(userId)) {
        return bot.sendMessage(chatId, '⚠️ Kamu sudah bergabung.');
    }

    session.players.push(userId)
    session.names.push(username)
    session.hp[userId] = 100
    session.turn = session.players[Math.floor(Math.random() * 2)]
    session.started = true

    bot.sendMessage(chatId, `🔥 ${username} bergabung!\n\n🎮 Pertarungan dimulai!\nGiliran: ${session.turn === session.players[0] ? session.names[0] : session.names[1]}\nKetik /serang`)
})

bot.onText(/^\/serang(@\w+)?$/, async (msg) => {
    const chatId = msg.chat.id
    const userId = msg.from.id
    const session = battleSessions[chatId]

    if (!session || !session.started) return bot.sendMessage(chatId, '❗ Tidak ada duel aktif.');
    if (session.turn !== userId) return bot.sendMessage(chatId, '⏳ Bukan giliran kamu.');

    const target = session.players.find(p => p !== userId)
    const damage = Math.floor(Math.random() * 21) + 10
    session.hp[target] -= damage

    const attackerName = session.names[session.players.indexOf(userId)]
    const targetName = session.names[session.players.indexOf(target)]

    let text = `💥 ${attackerName} menyerang ${targetName} dan memberi ${damage} damage!\n`
    text += `❤️ HP ${targetName}: ${Math.max(session.hp[target], 0)}\n`
    text += `❤️ HP ${attackerName}: ${session.hp[userId]}`

    if (session.hp[target] <= 0) {
        text += `\n\n🏆 ${attackerName} menang! Pertarungan selesai.`
        delete battleSessions[chatId]
    } else {
        session.turn = target
        text += `\n\n🔁 Giliran berikutnya: ${targetName}`
    }

    bot.sendMessage(chatId, text)
})

bot.onText(/^\/nyerah(@\w+)?$/, async (msg) => {
    const chatId = msg.chat.id
    const userId = msg.from.id
    const session = battleSessions[chatId]

    if (!session || !session.players.includes(userId)) return bot.sendMessage(chatId, '❌ Kamu tidak sedang bertarung.')

    const winnerIndex = session.players.findIndex(p => p !== userId)
    const winner = session.names[winnerIndex]

    bot.sendMessage(chatId, `🏳️ ${msg.from.first_name} menyerah!\n🏆 ${winner} menang!`)
    delete battleSessions[chatId]
})

const raceSessions = {};
const userStats = {}; // Simpan data pemain: poin, upgrade, dll.

bot.onText(/^\/balap(?:@yourbotusername)?$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const name = msg.from.first_name;

  if (raceSessions[chatId]) {
    return bot.sendMessage(chatId, '🚧 Perlombaan sedang berlangsung!');
  }

  if (!userStats[userId]) {
    userStats[userId] = { poin: 100, speed: 1, nitro: 1 };
  }

  raceSessions[chatId] = {
    player: { id: userId, name, position: 0 },
    bot: { name: 'BOT Turbo', position: 0 },
    lap: 1,
    maxLap: 10
  };

  bot.sendMessage(chatId, `🏁 Balapan dimulai!\n${name} vs BOT Turbo!\nTaruhan: 10 poin\nKetik /gas untuk memulai putaran pertama.`);

  // Kurangi poin taruhan
  userStats[userId].poin -= 10;
});

bot.onText(/^\/gas(?:@yourbotusername)?$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const session = raceSessions[chatId];
  if (!session || session.player.id !== userId) return;

  const user = userStats[userId];
  const userMove = Math.floor(Math.random() * (2 + user.speed)) + 1;
  const botMove = Math.floor(Math.random() * 3) + 1;

  session.player.position += userMove;
  session.bot.position += botMove;
  session.lap++;

  const progressBar = (pos) => '🚗' + '-'.repeat(pos) + '🏁';

  let text = `Lap ${session.lap - 1}/${session.maxLap}\n`;
  text += `👤 ${session.player.name}: ${progressBar(session.player.position)}\n`;
  text += `🤖 ${session.bot.name}: ${progressBar(session.bot.position)}\n`;

  if (session.lap > session.maxLap) {
    let winner;
    if (session.player.position >= session.bot.position) {
      winner = session.player.name;
      userStats[userId].poin += 25;
      text += `\n🏆 ${winner} menang! (+25 poin)`;
    } else {
      text += `\n💀 ${session.bot.name} menang!`;
    }

    delete raceSessions[chatId];
  } else {
    text += `\nKetik /gas untuk lap berikutnya!`;
  }

  bot.sendMessage(chatId, text);
});

bot.onText(/^\/balappoint$/, (msg) => {
  const userId = msg.from.id;
  const stats = userStats[userId] || { poin: 0 };
  bot.sendMessage(msg.chat.id, `💰 Poin kamu: ${stats.poin}`);
});

bot.onText(/^\/upgrade$/, (msg) => {
  const userId = msg.from.id;
  const stats = userStats[userId] || { poin: 0 };
  if (stats.poin < 20) return bot.sendMessage(msg.chat.id, '💸 Poin tidak cukup! Butuh 20 poin untuk upgrade.');

  stats.speed = (stats.speed || 1) + 1;
  stats.poin -= 20;
  bot.sendMessage(msg.chat.id, `🔧 Mobil kamu di-upgrade!\n⚙️ Speed: ${stats.speed}\n💰 Sisa poin: ${stats.poin}`);
});



class TicTacToe {
  constructor(playerX, playerO) {
    this.board = Array(3).fill().map(() => Array(3).fill(''));
    this.playerX = playerX;
    this.playerO = playerO;
    this.currentTurn = playerX;
    this.winner = null;
  }

  move(player, row, col) {
    if (this.winner || this.board[row][col]) return false;
    if (player.id !== this.currentTurn.id) return false;

    const symbol = player.id === this.playerX.id ? '❌' : '⭕';
    this.board[row][col] = symbol;

    if (this.checkWin(symbol)) {
      this.winner = player;
    } else if (this.isDraw()) {
      this.winner = 'draw';
    } else {
      this.currentTurn = player.id === this.playerX.id ? this.playerO : this.playerX;
    }
    return true;
  }

  checkWin(sym) {
    const b = this.board;
    const lines = [
      [b[0][0], b[0][1], b[0][2]],
      [b[1][0], b[1][1], b[1][2]],
      [b[2][0], b[2][1], b[2][2]],
      [b[0][0], b[1][0], b[2][0]],
      [b[0][1], b[1][1], b[2][1]],
      [b[0][2], b[1][2], b[2][2]],
      [b[0][0], b[1][1], b[2][2]],
      [b[0][2], b[1][1], b[2][0]],
    ];
    return lines.some(line => line.every(cell => cell === sym));
  }

  isDraw() {
    return this.board.flat().every(cell => cell !== '');
  }

  renderBoard() {
    return this.board.map((row, r) =>
      row.map((cell, c) => ({
        text: cell || '⬜', callback_data: `ttt_${r}_${c}`
      }))
    );
  }

  getStatus() {
    if (this.winner === 'draw') return '⚖️ Seri!';
    if (this.winner) return `🏆 ${this.winner.first_name} menang!`;
    return `🎯 Giliran: ${this.currentTurn.first_name}`;
  }
}

// Start game
bot.onText(/^\/tictactoe$/, async (msg) => {
  const reply = msg.reply_to_message;
  if (!reply || reply.from.is_bot) return bot.sendMessage(msg.chat.id, '⚠️ Balas pesan temanmu untuk mulai game!');

  const from = msg.from;
  const to = reply.from;
  const key = [from.id, to.id].sort().join(':');
  if (sessions.has(key)) return bot.sendMessage(msg.chat.id, '⚠️ Game sedang berlangsung!');

  const game = new TicTacToe(from, to);
  sessions.set(key, game);

  bot.sendMessage(msg.chat.id, `🎮 TicTacToe dimulai!\n${from.first_name} vs ${to.first_name}\n\n${game.getStatus()}`, {
    reply_markup: {
      inline_keyboard: game.renderBoard()
    }
  });

  bot.sendMessage(msg.chat.id, '🔽 Gunakan tombol di bawah untuk kontrol:', {
    reply_markup: {
      keyboard: [['🔁 Rematch', '❌ Menyerah', '🏁 Akhiri']],
      resize_keyboard: true,
      one_time_keyboard: false
    }
  });
});

// Handle inline board move
bot.on('callback_query', async (ctx) => {
  if (!ctx.data.startsWith('ttt_')) return;

  const [_, r, c] = ctx.data.split('_');
  const user = ctx.from;
  const key = Array.from(sessions.keys()).find(k => k.includes(user.id));
  if (!key) return bot.answerCallbackQuery(ctx.id, { text: '❌ Bukan game kamu!' });

  const game = sessions.get(key);
  const moved = game.move(user, +r, +c);
  if (!moved) return bot.answerCallbackQuery(ctx.id, { text: '❌ Tidak bisa langkah!' });

  const board = game.renderBoard();
  const text = `🎮 TicTacToe\n${game.playerX.first_name} vs ${game.playerO.first_name}\n\n${game.getStatus()}`;

  if (game.winner) sessions.delete(key);

  bot.editMessageText(text, {
    chat_id: ctx.message.chat.id,
    message_id: ctx.message.message_id,
    reply_markup: { inline_keyboard: board }
  });

  if (game.winner) {
    bot.sendMessage(ctx.message.chat.id, '🎉 Game selesai!', {
      reply_markup: { remove_keyboard: true }
    });
  }
});

// Handle bottom keyboard
bot.onText(/🔁 Rematch/, (msg) => {
  bot.sendMessage(msg.chat.id, `♻️ ${msg.from.first_name} ingin rematch!\nBalas pesan temanmu dan ketik /tictactoe`);
});

bot.onText(/❌ Menyerah/, (msg) => {
  const key = Array.from(sessions.keys()).find(k => k.includes(msg.from.id));
  if (!key) return bot.sendMessage(msg.chat.id, '⚠️ Tidak sedang bermain!');
  const game = sessions.get(key);
  const winner = game.playerX.id === msg.from.id ? game.playerO : game.playerX;

  bot.sendMessage(msg.chat.id, `😢 ${msg.from.first_name} menyerah!\n🏆 ${winner.first_name} menang!`, {
    reply_markup: { remove_keyboard: true }
  });

  sessions.delete(key);
});

bot.onText(/🏁 Akhiri/, (msg) => {
  const key = Array.from(sessions.keys()).find(k => k.includes(msg.from.id));
  if (!key) return bot.sendMessage(msg.chat.id, '⚠️ Tidak sedang bermain!');
  sessions.delete(key);
  bot.sendMessage(msg.chat.id, '⛔ Game diakhiri paksa.', {
    reply_markup: { remove_keyboard: true }
  });
});

const sharp = require("sharp");

bot.onText(/^\/infogempa$/, async (msg) => {
  const chatId = msg.chat.id;

  try {
    const res = await fetch('https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json');
    const json = await res.json();
    const data = json.Infogempa.gempa;

    let caption = `📡 *Informasi Gempa Terkini*\n\n`;
    caption += `📅 Tanggal: ${data.Tanggal}\n`;
    caption += `🕒 Waktu: ${data.Jam}\n`;
    caption += `📍 Wilayah: ${data.Wilayah}\n`;
    caption += `📈 Magnitudo: ${data.Magnitude}\n`;
    caption += `📏 Kedalaman: ${data.Kedalaman}\n`;
    caption += `📌 Koordinat: ${data.Coordinates}\n`;
    caption += `🧭 Lintang: ${data.Lintang} | Bujur: ${data.Bujur}\n`;
    caption += `⚠️ Potensi: *${data.Potensi}*\n`;
    if (data.Dirasakan) caption += `💬 Dirasakan: ${data.Dirasakan}\n`;
    caption += `\n❤️ Support: https://t.me/noxxasoloo`;

    const mapUrl = `https://data.bmkg.go.id/DataMKG/TEWS/${data.Shakemap}`;
    const buffer = await fetch(mapUrl).then(res => res.buffer());
    const image = await sharp(buffer).png().toBuffer();

    await bot.sendPhoto(chatId, image, {
      caption,
      parse_mode: "Markdown"
    });
  } catch (e) {
    console.error("Error infogempa:", e.message);
    bot.sendMessage(chatId, "❌ Gagal mengambil data gempa dari BMKG.");
  }
});


bot.onText(/\/ceklokasi(?:\s(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];

  try {
    if (msg.reply_to_message?.location) {
      // Balasan ke pesan lokasi
      const { latitude, longitude } = msg.reply_to_message.location;
      return await sendLokasiInfo(chatId, latitude, longitude);
    }

    if (!input) {
      return bot.sendMessage(chatId, '📍 Kirim perintah dengan lokasi, contoh:\n`/ceklokasi Jakarta`\n\nAtau balas pesan lokasi.', {
        parse_mode: 'Markdown'
      });
    }

    // Cari berdasarkan teks (misal: "Bandung")
    const geo = await axios.get('https://nominatim.openstreetmap.org/search', {
      params: {
        q: input,
        format: 'json',
        limit: 1
      },
      headers: {
        'User-Agent': 'TelegramBot'
      }
    });

    if (!geo.data.length) {
      return bot.sendMessage(chatId, '❌ Lokasi tidak ditemukan.');
    }

    const { lat, lon, display_name } = geo.data[0];
    await sendLokasiInfo(chatId, lat, lon, display_name);

  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, '❌ Gagal memproses lokasi.');
  }
});

async function sendLokasiInfo(chatId, lat, lon, name) {
  await bot.sendLocation(chatId, lat, lon);
  await bot.sendMessage(chatId,
    `📌 *Lokasi Ditemukan:*\n` +
    `🗺️ ${name || 'Koordinat'}\n` +
    `📍 Latitude: ${lat}\n` +
    `📍 Longitude: ${lon}`,
    { parse_mode: 'Markdown' }
  );
}


// Aktivitas berdasarkan waktu
const aktivitas = {
  pagi: [
    "Lagi nyari sarapan tapi dapurnya kosong 🍞",
    "Baru bangun, masih loading... ☕",
    "Lagi olahraga jempol scroll TikTok 🏋️‍♂️",
    "Lagi ngopi sambil liatin grup kelas 🧃",
    "Lagi cari motivasi hidup di Instagram ✨",
    "Lagi dengerin suara ayam tetangga berantem 🐓",
    "Lagi nonton matahari terbit tapi di wallpaper 🌄",
    "Lagi ngelamun di kamar mandi 🚿",
    "Lagi cari sendal sebelah yang hilang 🩴",
    "Lagi mikir kenapa hari Senin datangnya cepat 😩"
  ],
  siang: [
    "Lagi pura-pura kerja padahal baca komik 💼",
    "Lagi ngelamun di depan nasi padang 🍛",
    "Lagi ngadem di bawah AC kantor orang 😎",
    "Lagi dengerin dosen tapi mikirin liburan 📚",
    "Lagi rebutan colokan di kafe ☕🔌",
    "Lagi debat sama temen soal makan siang 🍜",
    "Lagi scroll Shopee padahal lagi bokek 🛒",
    "Lagi cari sinyal buat buka tugas 📶",
    "Lagi nyari alasan buat skip kelas 🙃",
    "Lagi ngintip jam, nunggu waktu pulang 🕒"
  ],
  sore: [
    "Lagi main bola pake sandal jepit ⚽",
    "Lagi liat langit biar kelihatan deep 🌇",
    "Lagi nyemil tahu bulat dadakan 🚚",
    "Lagi ngopi senja biar aesthetic ☕",
    "Lagi nungguin hujan turun tapi malah panas 🌤️",
    "Lagi jalan-jalan cari wifi gratis 🚶‍♂️",
    "Lagi mikir mau ngelakuin apa malam ini 🤔",
    "Lagi bantu emak belanja ke warung 🛍️",
    "Lagi main sama kucing tetangga 🐱",
    "Lagi galau liat story mantan 😔"
  ],
  malam: [
    "Lagi nonton anime sampe lupa tugas 📺",
    "Lagi galau dengerin lagu lawas 🎧",
    "Lagi curhat ke AI karena manusia nggak ngerti 🤖",
    "Lagi merenungi hidup sambil rebahan 😔",
    "Lagi nyalain lampu tumblr biar estetik 🌃",
    "Lagi ngetik chat panjang tapi nggak dikirim 💬",
    "Lagi nungguin pesan yang nggak bakal datang 📭",
    "Lagi nge-stalk akun orang random di medsos 🕵️‍♀️",
    "Lagi ngedit story padahal nggak jadi upload 📸",
    "Lagi begadang tapi nggak tau buat apa 🌙"
  ]
};

function getWaktu() {
  const jam = new Date().getHours();
  if (jam >= 4 && jam < 11) return 'pagi';
  if (jam >= 11 && jam < 15) return 'siang';
  if (jam >= 15 && jam < 18) return 'sore';
  return 'malam';
}

function getRandomAktivitas() {
  const waktu = getWaktu();
  const daftar = aktivitas[waktu];
  const acak = daftar[Math.floor(Math.random() * daftar.length)];
  return { waktu, teks: acak };
}

bot.onText(/\/ceksedangapa/, async (msg) => {
  const chatId = msg.chat.id;
  const nama = msg.from.first_name || 'Kamu';
  const { waktu, teks } = getRandomAktivitas();

  await bot.sendMessage(chatId,
    `🕒 *Waktu:* ${waktu.charAt(0).toUpperCase() + waktu.slice(1)}\n` +
    `🧐 ${nama} sedang apa?\n\n${teks}`, {
    parse_mode: 'Markdown'
  });
});

bot.onText(/^\/xnxx(?: (.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const query = match[1];

  if (!query) {
    return bot.sendMessage(chatId, '🔍 Contoh penggunaan:\n/xnxx jepang');
  }

  try {
    const res = await axios.get('https://www.ikyiizyy.my.id/search/xnxx', {
      params: {
        apikey: 'new',
        q: query
      }
    });

    const results = res.data.result;

    if (!results || results.length === 0) {
      return bot.sendMessage(chatId, `❌ Tidak ditemukan hasil untuk: *${query}*`, { parse_mode: 'Markdown' });
    }

    const text = results.slice(0, 3).map((v, i) => (
      `📹 *${v.title}*\n🕒 Durasi: ${v.duration}\n🔗 [Tonton Sekarang](${v.link})`
    )).join('\n\n');

    bot.sendMessage(chatId, `🔞 Hasil untuk: *${query}*\n\n${text}`, {
      parse_mode: 'Markdown',
      disable_web_page_preview: true
    });

  } catch (e) {
    console.error(e);
    bot.sendMessage(chatId, '❌ Terjadi kesalahan saat mengambil data.');
  }
});



const splitText = (text, maxLength = 4000) => {
  const parts = [];
  while (text.length > 0) {
    parts.push(text.slice(0, maxLength));
    text = text.slice(maxLength);
  }
  return parts;
};

bot.onText(/^\/pakustad(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromMessage = msg.reply_to_message;
  const inputText = match[1]?.trim() || fromMessage?.text || fromMessage?.caption;

  if (!inputText) {
    return bot.sendMessage(chatId, '⚠️ Masukin pertanyaannya dulu. Contoh:\n`/pakustad apa hukum pacaran?`', {
      parse_mode: 'Markdown'
    });
  }

  await bot.sendMessage(chatId, '🕌 Bertanya ke Pak Ustad...');

  const tmpDir = path.join(__dirname, './tmp');
  if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir);
  const tmpPath = path.join(tmpDir, 'pakustad.webp');

  // === BAGIAN VISUAL ===
  try {
    const response = await axios.get(`https://api.taka.my.id/tanya-ustad?quest=${encodeURIComponent(inputText)}`, {
      responseType: 'arraybuffer',
      validateStatus: () => true
    });

    const buffer = Buffer.from(response.data || []);
    const contentType = response.headers?.['content-type'] || '';

    console.log('[Pakustad] Status:', response.status);
    console.log('[Pakustad] Content-Type:', contentType);
    console.log('[Pakustad] Buffer Length:', buffer.length);

    if (response.status !== 200) throw new Error(`API status ${response.status}`);
    if (!contentType.startsWith('image/')) throw new Error('Konten bukan gambar.');
    if (buffer.length < 10240) throw new Error('Gambar terlalu kecil.');

    const webp = await sharp(buffer)
      .resize(512, 512, {
        fit: 'contain',
        background: { r: 0, g: 0, b: 0, alpha: 0 }
      })
      .webp()
      .toBuffer();

    fs.writeFileSync(tmpPath, webp);

    await bot.sendSticker(chatId, tmpPath);
  } catch (err) {
    console.error('[Visual Error]', err.message);
    await bot.sendMessage(chatId, `⚠️ Gagal ambil gambar jawaban Pak Ustad.\n*Detail:* ${err.message}`, {
      parse_mode: 'Markdown'
    });
  } finally {
    if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
  }

  // === BAGIAN AI ===
  const prompt = `
Kamu adalah seorang ustad yang menjawab secara singkat, serius, dan sesuai syariat Islam. Jawablah pertanyaan berikut ini dengan jawaban yang singkat dan to the point.

Pertanyaan: ${inputText}
Jawaban:
  `.trim();

  console.log('[AI Prompt]', prompt);

  try {
    const res = await fetch(`https://fastrestapis.fasturl.cloud/aillm/gpt-4o-turbo?ask=${encodeURIComponent(prompt)}`);
    const json = await res.json();

    if (!json || !json.result || typeof json.result !== 'string') {
      throw new Error('Respons AI tidak valid.');
    }

    const chunks = splitText(`📿 *Jawaban Pak Ustad:*\n\n${json.result.trim()}`);
    for (const chunk of chunks) {
      await bot.sendMessage(chatId, chunk, { parse_mode: 'Markdown' });
    }
  } catch (err) {
    console.error('[AI Error]', err.message);
    bot.sendMessage(chatId, '❌ Gagal menjawab via AI.');
  }
});

  const waifuList = [
    { url: "https://i.pinimg.com/736x/c3/53/d5/c353d5b69271d572a1b1bec8ff50f4b2.jpg" },
    { url: "https://i.pinimg.com/736x/40/28/4c/40284c46155cb812372e9895066b1b28.jpg" },
    { url: "https://i.pinimg.com/736x/52/c2/53/52c253338492f7b6185637378fefd2a1.jpg" },
  {"url":"https://i.pinimg.com/736x/44/ed/fd/44edfde351c836c760f7db7fa75bf77c.jpg"},
{"url":"https://i.pinimg.com/736x/eb/72/de/eb72de9117538e2bf445a6130030abe9.jpg"},
{"url":"https://i.pinimg.com/originals/53/2f/f8/532ff81b4f3bc92c8db823f2cea3d7a6.jpg"},
{"url":"https://i.pinimg.com/originals/91/5e/47/915e47e83801b992ff66d92dc8cc1244.jpg"},
{"url":"https://i.pinimg.com/originals/41/2e/f3/412ef39c4244861c287675498a9c6296.png"},
{"url":"https://i.pinimg.com/236x/85/65/a5/8565a5a34f0bec9e6c791ed927673374.jpg"},
{"url":"https://i.pinimg.com/originals/89/68/6e/89686edeb4316f53832e00ea7980cf01.jpg"},
{"url":"https://i.pinimg.com/736x/cd/53/b0/cd53b02aec22e034be15c42d81fea760.jpg"},
{"url":"https://i.pinimg.com/474x/4e/62/50/4e6250d42f22d2ef37181c7ba8caf9c7.jpg"},
{"url":"https://i.pinimg.com/736x/d4/66/47/d466476d52f5db16f042cc660eefb66d.jpg"},
{"url":"https://i.pinimg.com/736x/f6/16/7f/f6167f6a8cfb2e8471bb71ccb6983ef1.jpg"},
{"url":"https://i.pinimg.com/736x/0d/30/ef/0d30efe3b9ba40cf6ebb67b03d27c3dc.jpg"},
{"url":"https://i.pinimg.com/originals/23/8d/3a/238d3abe793fcdd198efd85308f1bce9.jpg"},
{"url":"https://i.pinimg.com/originals/74/35/b1/7435b1c713e956dd946c6721e19e6e14.jpg"},
{"url":"https://i.pinimg.com/564x/c4/cf/10/c4cf101520d8fe3329dbef541e75b69a.jpg"},
{"url":"https://i.pinimg.com/originals/e6/96/63/e69663c0f775438826c62e02c8b8eac8.jpg"},
{"url":"https://i.pinimg.com/originals/15/d1/c5/15d1c53899bafb2fd4b06b66bb6deb50.jpg"},
{"url":"https://i.pinimg.com/originals/8f/31/17/8f31178899d16701c0764cda76430433.png"},
{"url":"https://i.pinimg.com/originals/1d/a6/1a/1da61a5df4a31dd394758b035b17320e.jpg"},
{"url":"https://i.pinimg.com/736x/43/88/c8/4388c8f657e25e192b65dab3dea1818b.jpg"},
{"url":"https://i.pinimg.com/originals/42/e2/2c/42e22c72db81ff2c2900badfea2aaad1.jpg"},
{"url":"https://i.pinimg.com/originals/b6/03/80/b6038086c1c26c47f84c1f73851e74b2.jpg"},
{"url":"https://i.pinimg.com/736x/15/d9/f6/15d9f667d54648b378704e0db83d00cf.jpg"},
{"url":"https://i.pinimg.com/736x/3c/53/3e/3c533ee5fd2eb2bc09bf22537f41f340.jpg"},
{"url":"https://i.pinimg.com/originals/b6/32/dd/b632dd5f206d8295e4dfdac93411e75c.jpg"},
{"url":"https://i.pinimg.com/originals/a4/f2/ce/a4f2cec43267f37efd7cca541385d706.jpg"},
{"url":"https://i.pinimg.com/564x/8c/b8/c6/8cb8c6f4ccf92a35b0afe18484233106.jpg"},
{"url":"https://i.pinimg.com/736x/e8/78/42/e87842875dda5f9ff0aea490bd95088a.jpg"},
{"url":"https://i.pinimg.com/736x/d6/e5/9d/d6e59dae68d18854a857371ba2dc1ddd.jpg"},
{"url":"https://i.pinimg.com/236x/e0/0a/85/e00a85d7e42f81b5ab0caea47bbb827a.jpg"},
{"url":"https://i.pinimg.com/originals/ce/4f/4b/ce4f4b7635e8c8ab5c8db2911edd4249.jpg"},
{"url":"https://i.pinimg.com/originals/54/2a/01/542a017e6b4b677bc5d79f5bb8943476.jpg"},
{"url":"https://i.pinimg.com/originals/b5/7d/54/b57d54e40df741ddd37adbb0de41e004.jpg"},
{"url":"https://i.pinimg.com/originals/12/e5/35/12e535a4c8da2694f22809eb456886e9.png"},
{"url":"https://i.pinimg.com/originals/eb/74/1b/eb741b162e3255172bac9f19fa40d06c.jpg"},
{"url":"https://i.pinimg.com/736x/40/99/45/409945e40138e0ce9aca128adf8b39e4.jpg"},
{"url":"https://i.pinimg.com/564x/08/c7/2d/08c72d8d6153277e0c2fada59a42c1cb.jpg"},
{"url":"https://i.pinimg.com/736x/72/c9/39/72c9391de6204ab7d6020aed0722bd0d.jpg"},
{"url":"https://i.pinimg.com/originals/d6/b9/34/d6b934119056594f17a94192110cdbd8.jpg"},
{"url":"https://i.pinimg.com/originals/46/79/25/467925d52634fd098ab6890a23c33f30.jpg"},
{"url":"https://i.pinimg.com/736x/44/62/a3/4462a3cf3792a8cf12587fd7875d75bc.jpg"},
{"url":"https://i.pinimg.com/474x/bf/c4/d2/bfc4d2286865a6a20cd0c16c702e04af.jpg"},
{"url":"https://i.pinimg.com/736x/c1/a3/07/c1a30773b80a709e5a73350286447502.jpg"},
{"url":"https://i.pinimg.com/originals/44/4b/9b/444b9b8136ba26466b75136ef5d684cb.jpg"},
{"url":"https://i.pinimg.com/originals/79/ac/74/79ac742105acb071fac7eacbb2ff1e14.jpg"},
{"url":"https://i.pinimg.com/originals/c9/71/fd/c971fd4936c93b8343691952a88e3199.jpg"},
{"url":"https://i.pinimg.com/236x/8c/5a/8f/8c5a8f2112aac44c45de13f6ae86704f.jpg"},
{"url":"https://i.pinimg.com/originals/1b/f2/c5/1bf2c59a4b5c977ee61d0b5739da8a84.jpg"},
{"url":"https://i.pinimg.com/originals/42/2b/bf/422bbfbaaeb2d5b62ece67206cdb1ae5.jpg"},
{"url":"https://i.pinimg.com/474x/ee/47/d9/ee47d90d165a1985a6f1e95936aee4e2.jpg"},
{"url":"https://i.pinimg.com/originals/fa/ad/b0/faadb0977c90790eb72f051e4966059c.jpg"},
{"url":"https://i.pinimg.com/originals/dc/e9/f9/dce9f9beb37722c1d4c460065a37e252.jpg"},
{"url":"https://i.pinimg.com/originals/94/bd/e9/94bde9abb7f5d25ae7f1548b65c2869e.jpg"},
{"url":"https://i.pinimg.com/originals/04/eb/2f/04eb2f337389bf0b1247fb31aff9f93f.jpg"},
{"url":"https://i.pinimg.com/originals/bf/18/b3/bf18b3f21c536f3d4f442002c2f74684.jpg"},
{"url":"https://i.pinimg.com/originals/da/1c/ac/da1cac1d1cc919ec4362b6dac5bb539d.jpg"},
{"url":"https://i.pinimg.com/originals/6c/8d/19/6c8d196474794342a5b07ff57a78fecb.jpg"},
{"url":"https://i.pinimg.com/736x/fd/39/80/fd398084130bcfd15f1d1164bf4abb19.jpg"},
{"url":"https://i.pinimg.com/736x/ba/81/8b/ba818b7b031bc2c0031f29038ce49947.jpg"},
{"url":"https://i.pinimg.com/originals/6d/6e/45/6d6e45825121046f929e26fe02b828f3.jpg"},
{"url":"https://i.pinimg.com/736x/86/c8/5d/86c85d469d2b0d10f96dafcd76bc6915.jpg"},
{"url":"https://i.pinimg.com/originals/f0/49/5c/f0495c7f50d78e28e31645d8adc38603.jpg"},
{"url":"https://i.pinimg.com/originals/9a/fa/d1/9afad13f18ada18954231ee93708040b.jpg"},
{"url":"https://i.pinimg.com/736x/c2/21/1f/c2211fa07896c211f8f345df09959591.jpg"},
{"url":"https://i.pinimg.com/originals/27/ca/b1/27cab176e51f16f4513c0e139c52a401.png"},
{"url":"https://i.pinimg.com/originals/b3/6e/84/b36e84613cc59a7b5c5e280ce7a91502.jpg"},
{"url":"https://i.pinimg.com/originals/a7/52/84/a75284bb38036502ea6638d5ae2a3dd2.jpg"},
{"url":"https://i.pinimg.com/originals/e6/e3/87/e6e3876124a051597fd113a3f3308941.png"},
{"url":"https://i.pinimg.com/564x/15/29/ce/1529ce3e7b0301af49d80e2af0028385.jpg"},
{"url":"https://i.pinimg.com/originals/b2/33/68/b233685b5910013a24d7a970ee77fa03.jpg"},
{"url":"https://i.pinimg.com/236x/39/7b/cb/397bcbf7d8b2e77eab68f3a9022bddef.jpg"},
{"url":"https://i.pinimg.com/564x/5f/da/45/5fda45eb93f281ec982267f88eeaf90c.jpg"},
{"url":"https://i.pinimg.com/736x/a3/75/c3/a375c3877c5e9ac2c431d496551cbd40.jpg"},
{"url":"https://i.pinimg.com/originals/e2/e5/b7/e2e5b7f0eddf1dfaab585c4373a78ff5.jpg"},
{"url":"https://i.pinimg.com/originals/9c/ec/9b/9cec9b35d2001bf571afdb8f59752fdf.jpg"},
{"url":"https://i.pinimg.com/originals/89/08/a9/8908a93add420e241916092415bbe75a.png"},
{"url":"https://i.pinimg.com/736x/b3/9d/c6/b39dc6c0d4e8bcefd9b45414680af57f.jpg"},
{"url":"https://i.pinimg.com/originals/05/cb/c4/05cbc42b3a81f63377abf978cf6c03f3.jpg"},
{"url":"https://i.pinimg.com/originals/63/8f/70/638f70ce3de17589a9f3dc163e30d7b1.jpg"},
{"url":"https://i.pinimg.com/originals/3b/f3/e2/3bf3e24281dbeefd964ec56b63f3b079.jpg"},
{"url":"https://i.pinimg.com/originals/a9/94/fb/a994fbc39e15f70a78ea462a851f149f.jpg"},
{"url":"https://i.pinimg.com/originals/94/41/d0/9441d0191fe1a1adc663f53acd1149cb.jpg"},
{"url":"https://i.pinimg.com/originals/63/ed/bf/63edbf309339c3aac5a33b62d5b8a0a2.jpg"},
{"url":"https://i.pinimg.com/564x/71/c4/01/71c40151a067cfd1682969e4a8e47eb6.jpg"},
{"url":"https://i.pinimg.com/736x/a9/67/96/a967962e02779b95f1464861cb53076e.jpg"},
{"url":"https://i.pinimg.com/736x/53/62/da/5362da49580e1b4c6225144c7deb2dd0.jpg"},
{"url":"https://i.pinimg.com/736x/3f/69/97/3f6997166bc2fa89d05779cb2cbc7a8d.jpg"},
{"url":"https://i.pinimg.com/564x/4a/ec/f8/4aecf8ac4d14e7fd3118c58082c01a1c.jpg"},
{"url":"https://i.pinimg.com/236x/28/2f/81/282f81f5de984104a9227583b39df527.jpg"},
{"url":"https://i.pinimg.com/originals/27/41/11/27411120fcee8e125cef86280d58c80d.jpg"},
{"url":"https://i.pinimg.com/736x/59/19/35/591935f55e03142fcf1a3fe1a49e63d6--anime-kimono-kawaii-anime.jpg"},
{"url":"https://i.pinimg.com/originals/ec/c5/8b/ecc58b5b8c4883c5ef8b8f253b4768c2.png"},
{"url":"https://i.pinimg.com/originals/f9/75/66/f975668faecfdae1ab019dd6d5681b51.jpg"},
{"url":"https://i.pinimg.com/originals/64/61/2b/64612be0159860b88f280e7081770f3c.jpg"},
{"url":"https://i.pinimg.com/736x/8d/73/c3/8d73c37ac839b53d1994995ccfa634aa.jpg"},
{"url":"https://i.pinimg.com/originals/60/c4/62/60c462a2f5b991cbce026b09fab25769.jpg"},
{"url":"https://i.pinimg.com/originals/e7/3a/2a/e73a2a1325458dca54350c75598f68d0.jpg"},
{"url":"https://i.pinimg.com/736x/10/85/31/1085317f6e01744da22de9077ea68af3.jpg"},
{"url":"https://i.pinimg.com/originals/36/b2/7b/36b27beb4433279a44b93769c4f02a2d.jpg"},
{"url":"https://i.pinimg.com/originals/8f/10/a4/8f10a4730033aaf94a2504139e277daf.jpg"},
{"url":"https://i.pinimg.com/474x/b9/44/7e/b9447e911a91d837b787b368138f4d12.jpg"},
{"url":"https://i.pinimg.com/originals/8d/f2/85/8df28530ca82c87170f951c7b24149b8.jpg"},
{"url":"https://i.pinimg.com/originals/15/9f/51/159f51a34ffbe8052e903656e714a512.jpg"},
{"url":"https://i.pinimg.com/originals/f9/2b/71/f92b716bc5959bf76284c8289cdcfe9a.png"},
{"url":"https://i.pinimg.com/originals/6d/cc/62/6dcc6290532e1988e991f3f2e1374b0f.jpg"},
{"url":"https://i.pinimg.com/originals/73/b9/f0/73b9f0f9c77224472befd458ed5edffd.png"},
{"url":"https://i.pinimg.com/originals/36/4b/90/364b905f23b86dbdc4e8cfc1d17d37b5.jpg"},
{"url":"https://i.pinimg.com/736x/b3/30/b8/b330b852952404650fb95514e64ee214.jpg"},
{"url":"https://i.pinimg.com/originals/36/7e/be/367ebec29f313aa9ff4a118741f37b6d.jpg"},
{"url":"https://i.pinimg.com/736x/50/20/cb/5020cbac8e84fda0b8b7b6d97b76415f.jpg"},
{"url":"https://i.pinimg.com/originals/fb/e0/15/fbe0152aec760539d96acd91ad28c345.png"},
{"url":"https://i.pinimg.com/originals/5e/7b/eb/5e7beb883bc07319921dfbca6d4d6dfa.jpg"},
{"url":"https://i.pinimg.com/736x/0d/e9/d8/0de9d89ec8f5b64a44b80cf9ac009713.jpg"},
{"url":"https://i.pinimg.com/originals/91/5d/b7/915db7bdf6de7b154b947c701f353da4.png"},
{"url":"https://i.pinimg.com/originals/d0/83/81/d0838135c082f0906032fbf02d6084d5.png"},
{"url":"https://i.pinimg.com/originals/98/75/37/98753784596979d39d00d92e120ddb8c.jpg"},
{"url":"https://i.pinimg.com/originals/42/ff/74/42ff7423988923098a5ff9f7a470e9f4.png"},
{"url":"https://i.pinimg.com/originals/bb/c3/42/bbc3425bd25ab8b4d9da0471e4a902c5.jpg"},
{"url":"https://i.pinimg.com/736x/92/d3/cb/92d3cb181a6dc6e654854c0a637ccba1.jpg"},
{"url":"https://i.pinimg.com/originals/d1/01/3d/d1013d31a1aeab172bd9c02404ad4065.jpg"},
{"url":"https://i.pinimg.com/736x/4b/45/63/4b456311f3d56ae388ea5851eafee7bb.jpg"},
{"url":"https://i.pinimg.com/originals/70/06/92/70069213d0f54a4409a3d5176268e712.jpg"},
{"url":"https://i.pinimg.com/736x/de/9d/23/de9d23a68466f911290dba5e37db7e72.jpg"},
{"url":"https://i.pinimg.com/736x/96/ef/ad/96efad6db9cdeeb107eca1c6a9e943cf.jpg"},
{"url":"https://i.pinimg.com/originals/c3/02/b1/c302b10840b3521f732b113cfff67b6f.png"},
{"url":"https://i.pinimg.com/originals/3d/ee/a7/3deea7238ac7ae18c30763ee95545b5d.jpg"},
{"url":"https://i.pinimg.com/originals/ea/40/bb/ea40bb01b91dd575e409af0c95befeb1.jpg"},
{"url":"https://i.pinimg.com/originals/e0/bf/15/e0bf15b0696753b4c3724d06f58af313.png"},
{"url":"https://i.pinimg.com/originals/05/4f/df/054fdfbc2045fd65876c2dc0934e6547.png"},
{"url":"https://i.pinimg.com/originals/be/24/3b/be243b5b9238c63679ea69feb8c67856.jpg"},
{"url":"https://i.pinimg.com/originals/1a/e4/de/1ae4defe9ed245a145aeb65591ba3967.jpg"},
{"url":"https://i.pinimg.com/236x/7a/d8/7a/7ad87a4eb06bdabd9065045c36d2b329.jpg"},
{"url":"https://i.pinimg.com/originals/ac/b2/6c/acb26c516d6681e922f6aeb3f3848d2f.jpg"},
{"url":"https://i.pinimg.com/originals/f3/fe/61/f3fe619cd29b07f0a8f8b213f2005bba.jpg"},
{"url":"https://i.pinimg.com/originals/a0/9b/86/a09b864c3234ea0c6c420187e4c0a721.jpg"},
{"url":"https://i.pinimg.com/736x/93/30/b7/9330b732e09e0201509f2728f81c61f0.jpg"},
{"url":"https://i.pinimg.com/474x/31/f5/5b/31f55bd574c5262b830ec9f5c442675a.jpg"},
{"url":"https://i.pinimg.com/originals/67/09/ee/6709ee13ea60b70d1aaaac9f2060c8b8.jpg"},
{"url":"https://i.pinimg.com/originals/66/60/c9/6660c99808c9ebb40fbab1e0c82bb3c9.jpg"},
{"url":"https://i.pinimg.com/originals/f8/fe/ce/f8fece5a97db23cfdb4862cd77ed60ba.jpg"},
{"url":"https://i.pinimg.com/originals/68/46/14/6846147ae61c96a2c866c6d64b02dd4c.jpg"},
{"url":"https://i.pinimg.com/originals/57/29/0f/57290f004bc38e6c0236ce2449504038.jpg"},
{"url":"https://i.pinimg.com/originals/4e/3e/fe/4e3efe1e994eb425465937b493ebcace.jpg"},
{"url":"https://i.pinimg.com/originals/0e/c9/a4/0ec9a4023e11a63f1443565b51162d51.jpg"},
{"url":"https://i.pinimg.com/originals/a3/de/f2/a3def24de57de9c335889bdaf1e38675.jpg"},
{"url":"https://i.pinimg.com/originals/e2/f6/0b/e2f60bd206f7ae4c337e4d4b8fec9dd4.jpg"},
{"url":"https://i.pinimg.com/736x/de/cf/60/decf60580d3ce62a35e1e53614cbaaea.jpg"},
{"url":"https://i.pinimg.com/originals/4e/08/ec/4e08ecba60a4e2fea2c8b7e2e537c596.jpg"},
{"url":"https://i.pinimg.com/originals/02/28/98/0228989655b4b78085b9eaf63f2de331.jpg"},
{"url":"https://i.pinimg.com/originals/cc/cc/89/cccc89172f7c17851dec4b97abde669f.png"},
{"url":"https://i.pinimg.com/564x/75/69/9f/75699f5ef9c294513d3a24393b09c978.jpg"},
{"url":"https://i.pinimg.com/originals/27/ed/88/27ed88ea911360f051060866451a14eb.jpg"},
{"url":"https://i.pinimg.com/originals/4f/bd/54/4fbd547a10ea9bfccde6e3f1e04fb9e7.png"},
{"url":"https://i.pinimg.com/originals/15/47/9b/15479bb3c033da49c26310682b370976.jpg"},
{"url":"https://i.pinimg.com/736x/e8/77/56/e87756dd6bcc2727b836876a0c784c7c.jpg"},
{"url":"https://i.pinimg.com/originals/39/bc/ab/39bcabbfff2647f37ad49df75d486aa1.png"},
{"url":"https://i.pinimg.com/originals/6a/39/8e/6a398e9554b6b438d208ea60f0f17e9a.jpg"},
{"url":"https://i.pinimg.com/736x/da/be/80/dabe804328738cd10c3f702937f0b393.jpg"},
{"url":"https://i.pinimg.com/originals/4e/5e/dc/4e5edc8963b81fb714e54c813a169fb7.jpg"},
{"url":"https://i.pinimg.com/originals/15/48/e0/1548e0fffaf2f582d5c6b4b7fe61dbb0.jpg"},
{"url":"https://i.pinimg.com/originals/fa/36/d9/fa36d966437565d96b555811f0a4481c.jpg"},
{"url":"https://i.pinimg.com/originals/b3/3c/4b/b33c4bcdcf147931a428b4474d64854d.png"},
{"url":"https://i.pinimg.com/originals/08/43/e7/0843e7ce782fc9f27151e3ab2e1734b9.png"},
{"url":"https://i.pinimg.com/originals/fd/08/09/fd08091dde0df47db1e7355f80ef144e.jpg"},
{"url":"https://i.pinimg.com/originals/52/bb/68/52bb687687bfa006bc71d145a7a885b2.jpg"},
{"url":"https://i.pinimg.com/originals/44/eb/3d/44eb3dbec735cbe328cdd8e2b37e1197.jpg"},
{"url":"https://i.pinimg.com/564x/7b/27/72/7b2772bc12777eba1b7af103f610f9d9.jpg"},
{"url":"https://i.pinimg.com/originals/f2/01/bd/f201bdd2532c7034cdc0e3a779ca5137.jpg"},
{"url":"https://i.pinimg.com/736x/41/2d/e7/412de7747b86518bd2b1fc0b69556bb5.jpg"},
{"url":"https://i.pinimg.com/originals/4c/3a/fe/4c3afe0c22d19c78f32c687aa9b4ea20.jpg"},
{"url":"https://i.pinimg.com/originals/62/74/c0/6274c0d42db0b928d6cec37d498c8f30.jpg"},
{"url":"https://i.pinimg.com/originals/91/0a/05/910a050858ead717bf0a85b4c91b13eb.jpg"},
{"url":"https://i.pinimg.com/originals/24/4e/35/244e35b1a55df0bc8651f45c98213a6d.jpg"},
{"url":"https://i.pinimg.com/originals/11/41/40/114140962dd288b85e72443b8b4fea2e.jpg"},
{"url":"https://i.pinimg.com/originals/dd/cb/d7/ddcbd7aa37278e177c3f8dce9b932d34.jpg"},
{"url":"https://i.pinimg.com/originals/30/42/bf/3042bf1d758e0e7575d3f52725e65011.png"},
{"url":"https://i.pinimg.com/originals/63/23/ea/6323eadeb278901c9a3012882efcb37c.png"},
{"url":"https://i.pinimg.com/originals/15/d0/66/15d06684c88d6158afcaf4a420ee3b30.jpg"},
{"url":"https://i.pinimg.com/originals/11/46/fd/1146fd486ada70d44ffc7ca295116229.jpg"},
{"url":"https://i.pinimg.com/originals/d0/76/10/d0761081beb385185d9124f52560dadf.jpg"},
{"url":"https://i.pinimg.com/originals/1f/c6/bf/1fc6bf6f3b3c9e78c288951b4a161c54.png"},
{"url":"https://i.pinimg.com/originals/62/ad/3d/62ad3d807771ee99b948040568f3e4c1.png"},
{"url":"https://i.pinimg.com/originals/b2/8e/52/b28e526c16bedca0954636718ff28fe7.png"},
{"url":"https://i.pinimg.com/originals/db/06/92/db069236209fd30b6020dfa6acef9f2f.jpg"},
{"url":"https://i.pinimg.com/originals/41/91/e0/4191e01d3a8596160980d6345647023d.jpg"},
{"url":"https://i.pinimg.com/originals/15/2e/d5/152ed5d86e61b7d5f8386bdbf628e9a0.png"},
{"url":"https://i.pinimg.com/originals/1b/d9/2d/1bd92d837d65cdda3e87dc240d531de6.jpg"},
{"url":"https://i.pinimg.com/originals/2f/b1/15/2fb115ddccb13b43a4b4c00cd3de2254.jpg"},
{"url":"https://i.pinimg.com/originals/6b/04/fe/6b04fe8af13392d5215e9793d79c5424.png"},
{"url":"https://i.pinimg.com/736x/26/7a/fc/267afcf2f421e84593c51cf88dd391ff.jpg"},
{"url":"https://i.pinimg.com/originals/05/3d/a8/053da85abb650f36fbd023f0f55a1b0b.jpg"},
{"url":"https://i.pinimg.com/originals/b9/e1/ed/b9e1edd56d8338f8def9ee6e9e32cb33.png"},
{"url":"https://i.pinimg.com/originals/c6/71/d6/c671d68d7ee45e7f7ec3dbd8b20fdd50.png"},
{"url":"https://i.pinimg.com/originals/1b/88/73/1b8873eb9da1174d70eb26ea005bad65.png"},
{"url":"https://i.pinimg.com/originals/fc/de/3c/fcde3c888c4680d97bd419586c8b8f69.png"},
{"url":"https://i.pinimg.com/originals/a2/26/54/a22654c645a7c0ab482983141d4c9e7f.jpg"},
{"url":"https://i.pinimg.com/originals/79/15/f1/7915f11c61fb6374b8aa20dfdba5257a.jpg"},
{"url":"https://i.pinimg.com/originals/41/23/f2/4123f28655aa4874a956d2ba0147e296.jpg"},
{"url":"https://i.pinimg.com/736x/b7/3a/96/b73a9642a5380c8941352022cfc07371.jpg"},
{"url":"https://i.pinimg.com/736x/05/6d/23/056d23fff769555983d3b72b97d13d1f.jpg"},
{"url":"https://i.pinimg.com/originals/4a/77/4a/4a774a04858fa8dc8a04a0dbc22af729.jpg"},
{"url":"https://i.pinimg.com/originals/50/38/98/503898e84962573df440773b224a9d04.jpg"},
{"url":"https://i.pinimg.com/originals/93/c6/fb/93c6fbaf62f8b797eea55f7ae79e356d.jpg"},
{"url":"https://i.pinimg.com/736x/44/ed/fd/44edfde351c836c760f7db7fa75bf77c.jpg"},
{"url":"https://i.pinimg.com/originals/80/a9/2d/80a92d9bf7123b4906158c5a63d94ff0.jpg"},
{"url":"https://i.pinimg.com/originals/d6/51/a8/d651a8546d44aa0f2ca16e7ec610ee25.jpg"},
{"url":"https://i.pinimg.com/564x/92/a6/e2/92a6e29533a70918bcc61abba55eadf5.jpg"},
{"url":"https://i.pinimg.com/474x/04/89/59/048959e47907e5622cc7ad9c8d54c965.jpg"},
{"url":"https://i.pinimg.com/736x/08/3e/9e/083e9e711c4a62da298115aa286fc2de.jpg"},
{"url":"https://i.pinimg.com/originals/c2/c1/9f/c2c19f5b8c573a3493589add1087a0af.jpg"},
{"url":"https://i.pinimg.com/originals/57/d2/3e/57d23e7f36de853db205e2f8edf57dc9.jpg"},
{"url":"https://i.pinimg.com/originals/cf/2a/cc/cf2acc66e631382da0197da4c59dbada.jpg"},
{"url":"https://i.pinimg.com/originals/ee/9a/4e/ee9a4ee17b3caefeeb21411abc866acf.jpg"},
{"url":"https://i.pinimg.com/originals/82/18/ec/8218ec505a0fe7ed65f66e7624900e1c.jpg"},
{"url":"https://i.pinimg.com/originals/df/5f/4e/df5f4e18d1e48b9466913ba1999883e9.jpg"},
{"url":"https://i.pinimg.com/736x/df/ec/f0/dfecf0baa693b8c1edfb55c830c9dd7d.jpg"},
{"url":"https://i.pinimg.com/474x/5a/6d/7b/5a6d7b276a81e41ae2619d66941b710b.jpg"},
{"url":"https://i.pinimg.com/originals/f1/64/ee/f164ee68add02194e673f2682913a258.jpg"},
{"url":"https://i.pinimg.com/564x/4e/03/a5/4e03a5e88c2a0b1fda9f8428beb611b4.jpg"},
{"url":"https://i.pinimg.com/originals/bb/56/0e/bb560e6b81e4ea2740f4cb967018bebe.jpg"},
{"url":"https://i.pinimg.com/474x/83/02/8a/83028a2842e9f7ddf99c934fcecc584f.jpg"},
{"url":"https://i.pinimg.com/originals/61/a4/a5/61a4a549a8d1bf9e1293f8ee373aa143.jpg"},
{"url":"https://i.pinimg.com/736x/19/74/db/1974db8964d3c9287414a9d3d6cbeccf.jpg"},
{"url":"https://i.pinimg.com/736x/aa/6b/df/aa6bdf98cbc9e1fc741c36682fa3e838.jpg"},
{"url":"https://i.pinimg.com/originals/e3/13/a8/e313a86922cecd050bb2561425ad8257.png"},
{"url":"https://i.pinimg.com/736x/24/3c/71/243c71b9fdbb25b51037ab3ac8928eb7.jpg"},
{"url":"https://i.pinimg.com/originals/fa/ad/b0/faadb0977c90790eb72f051e4966059c.jpg"},
{"url":"https://i.pinimg.com/736x/c1/0c/f2/c10cf211537491a3c1383a7bbd539d38.jpg"},
{"url":"https://i.pinimg.com/originals/08/78/e3/0878e32620b43b1adbd295be23fed001.jpg"},
{"url":"https://i.pinimg.com/originals/af/08/4a/af084aee5e2043131dad14b8f2a99e6e.jpg"},
{"url":"https://i.pinimg.com/originals/bc/a8/c6/bca8c65b62c52a78362c9239ce894d0b.jpg"},
{"url":"https://i.pinimg.com/originals/2f/69/92/2f6992cd3b288bc94d2093cd184dca56.jpg"},
{"url":"https://i.pinimg.com/originals/25/e3/28/25e32849ce741ef6949d440f25d92332.jpg"},
{"url":"https://i.pinimg.com/originals/6f/78/9a/6f789a9ea17311ee72ac8ae0ae8c66c0.jpg"},
{"url":"https://i.pinimg.com/originals/d3/85/63/d38563715af9d94f6fc6092563b73e8d.jpg"},
{"url":"https://i.pinimg.com/originals/71/8e/1e/718e1e0ffb55fc0fc288c1567bbf54b8.jpg"},
{"url":"https://i.pinimg.com/originals/76/14/ea/7614ea924f23dae9fed86a85d313ac3f.jpg"},
{"url":"https://i.pinimg.com/originals/42/3d/bc/423dbc54927907734290f1c1d5187edb.jpg"},
{"url":"https://i.pinimg.com/originals/bc/3a/1f/bc3a1f36e19e36c590bb8942ba1618de.png"},
{"url":"https://i.pinimg.com/originals/8a/a1/f4/8aa1f4f164d3f1317fded035ad59e39e.jpg"},
{"url":"https://i.pinimg.com/736x/e6/83/f5/e683f50350031cb53687a396afba39ff.jpg"},
{"url":"https://i.pinimg.com/474x/a2/21/13/a22113ccae86c391e3cd2594ec59d53b.jpg"},
{"url":"https://i.pinimg.com/originals/de/4b/10/de4b105d0560e5f01e77cd0fcb69570e.jpg"},
{"url":"https://i.pinimg.com/474x/36/e5/50/36e5509ed7a49a0a15c2d2ef283acdbe.jpg"},
{"url":"https://i.pinimg.com/originals/25/bb/20/25bb205317b48a1c987246e087405568.jpg"},
{"url":"https://i.pinimg.com/originals/3c/47/06/3c47069432b5fadb7c358099a36f063b.jpg"},
{"url":"https://i.pinimg.com/736x/ba/77/92/ba77924eceab03b00827ef2b8519451a.jpg"},
{"url":"https://i.pinimg.com/originals/89/4d/10/894d10830c341c5aa5bd3c0fec83e76c.jpg"},
{"url":"https://i.pinimg.com/originals/89/55/bd/8955bdaca7aa8c8b6399644ba5c5644b.png"},
{"url":"https://i.pinimg.com/736x/76/fe/2a/76fe2a24de79ed2945e331e0589f2caa.jpg"},
{"url":"https://i.pinimg.com/originals/05/78/58/05785877c531ea28277ac687a06d7eb9.jpg"},
{"url":"https://i.pinimg.com/564x/b4/e4/9f/b4e49f4cead77dbe61710d4a044aaaa3.jpg"},
{"url":"https://i.pinimg.com/736x/68/f4/6d/68f46d61769150315c316fc6e656f374.jpg"},
{"url":"https://i.pinimg.com/originals/c1/23/8a/c1238a1500c4901d5f51f715f857ee1f.png"},
{"url":"https://i.pinimg.com/originals/de/3b/ba/de3bba5cd3b2186f11b7587abad2bea5.jpg"},
{"url":"https://i.pinimg.com/280x280_RS/29/8b/f5/298bf53f120299775f101d2bc0fc0908.jpg"},
{"url":"https://i.pinimg.com/564x/f1/72/68/f17268e705b00f53784c4ff3852722ac.jpg"},
{"url":"https://i.pinimg.com/originals/d9/73/d7/d973d7bbf94dfa270295d78954b9a129.jpg"},
{"url":"https://i.pinimg.com/originals/9b/f4/07/9bf407786accda157d99b0deaceaeff0.jpg"},
{"url":"https://i.pinimg.com/564x/fd/cf/a2/fdcfa2a7b4fca5a93640fc648cf47242.jpg"},
{"url":"https://i.pinimg.com/originals/1b/5b/53/1b5b53c1971fa4138bc1c8f0e0d851c1.png"},
{"url":"https://i.pinimg.com/280x280_RS/65/fd/37/65fd37f9e585ea92637cdcba2ed5383f.jpg"},
{"url":"https://i.pinimg.com/736x/6a/93/97/6a9397fc90466a45adec83003b6b8ff1.jpg"},
{"url":"https://i.pinimg.com/736x/5a/21/38/5a2138e9c516999c5fddb9094de051ae.jpg"},
{"url":"https://i.pinimg.com/originals/8b/f8/3b/8bf83b14a1efdc4d0a04b45146f85324.jpg"},
{"url":"https://i.pinimg.com/736x/79/94/ed/7994ed900039094d0ea45dadc9b088a2.jpg"},
{"url":"https://i.pinimg.com/236x/85/65/a5/8565a5a34f0bec9e6c791ed927673374.jpg"},
{"url":"https://i.pinimg.com/originals/4d/68/ea/4d68eade7a54351dce8f6aae76f52501.jpg"},
{"url":"https://i.pinimg.com/originals/5e/0c/19/5e0c198be3b7b094533f0f9d9a0d05d3.jpg"},
{"url":"https://i.pinimg.com/originals/e4/ba/d0/e4bad04892bb8269715abda58352a2e5.png"},
{"url":"https://i.pinimg.com/originals/99/06/fd/9906fdde250e68f81367508f3ef5bc9c.jpg"},
{"url":"https://i.pinimg.com/736x/01/2b/9e/012b9e7543c33638a4cc970d5a4e39c9.jpg"},
{"url":"https://i.pinimg.com/originals/99/36/36/993636cce9b8b4a82ca84153b239780e.jpg"},
{"url":"https://i.pinimg.com/564x/c6/91/d5/c691d523b5c65c62deb3b57516c19b1b.jpg"},
{"url":"https://i.pinimg.com/originals/cd/e3/63/cde363113146648f9367a9cadd56e90f.jpg"},
{"url":"https://i.pinimg.com/originals/ef/8e/e9/ef8ee98953c8a8239f83208147058753.jpg"},
{"url":"https://i.pinimg.com/originals/7a/ad/63/7aad6333a788bc12cc362fcadd96ee05.jpg"},
{"url":"https://i.pinimg.com/474x/db/a8/1f/dba81f1ce9873e52b970f69764332824.jpg"},
{"url":"https://i.pinimg.com/736x/91/79/c5/9179c56ea350e37c66065a08e66c9be3.jpg"},
{"url":"https://i.pinimg.com/736x/fe/26/6f/fe266f58054cc29b48c59c4221f45cfa.jpg"},
{"url":"https://i.pinimg.com/originals/9a/72/ed/9a72ede6d15b7ea2a0abe72f63eb0325.png"},
{"url":"https://i.pinimg.com/originals/e7/91/1c/e7911ca981856a6b244d5ca817d66f17.jpg"},
{"url":"https://i.pinimg.com/originals/0f/da/85/0fda854a569af4560f859c7d0e65a9af.png"},
{"url":"https://i.pinimg.com/originals/a9/ab/38/a9ab388d8feaf67ccb396ee91e988aa5.jpg"},
{"url":"https://i.pinimg.com/736x/33/ed/c9/33edc95108e2c8104d8a392cb03206c0.jpg"},
{"url":"https://i.pinimg.com/originals/68/2c/c0/682cc0ced90762268112e2c88c03d9db.jpg"},
{"url":"https://i.pinimg.com/474x/4e/62/50/4e6250d42f22d2ef37181c7ba8caf9c7.jpg"},
{"url":"https://i.pinimg.com/736x/cb/14/13/cb1413695246b59c760a8cf824549e9c.jpg"},
{"url":"https://i.pinimg.com/originals/b6/ef/b3/b6efb3057388568f431b00f54bd73084.jpg"},
{"url":"https://i.pinimg.com/564x/99/83/5a/99835aa6cc644df3296fcbb0e369bf29.jpg"},
{"url":"https://i.pinimg.com/originals/cc/b7/fb/ccb7fbefcac8c65452dc7cb7049800f8.jpg"},
{"url":"https://i.pinimg.com/originals/00/47/9a/00479aac1d7af8b996018d89f85e7f0b.jpg"},
{"url":"https://i.pinimg.com/originals/91/69/44/916944a5a24270ba6df2a164a0276cf1.jpg"},
{"url":"https://i.pinimg.com/originals/fc/e1/c6/fce1c6649ab847caf1efaf91b7408483.png"},
{"url":"https://i.pinimg.com/originals/8c/bb/18/8cbb18000f0be5bbc35ad9f00ddb0601.jpg"},
{"url":"https://i.pinimg.com/originals/3b/e0/74/3be0748e87ad689ed8bdbdb5918f81f4.jpg"},
{"url":"https://i.pinimg.com/originals/de/8e/e4/de8ee4b43a3b0b579626f5106b4c0a02.png"}
];

function getRandomWaifu() {
  return waifuList[Math.floor(Math.random() * waifuList.length)];
}

// Command /waifu
bot.onText(/\/waifu/, async (msg) => {
  const chatId = msg.chat.id;
  const waifu = getRandomWaifu();

  await bot.sendPhoto(chatId, waifu.url, {
    caption: '💘 Waifu hari ini datang buat nemenin kamu~',
    reply_markup: {
      keyboard: [
        ['🔁 Next Waifu', '❌ Selesai']
      ],
      resize_keyboard: true,
      one_time_keyboard: false
    }
  });
});

// Tangani tombol custom keyboard
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const text = msg.text;

  if (text === '🔁 Next Waifu') {
    const waifu = getRandomWaifu();
    await bot.sendPhoto(chatId, waifu.url, {
      caption: '💘 Ini waifu baru spesial buat kamu!',
      reply_markup: {
        keyboard: [
          ['🔁 Next Waifu', '❌ Selesai']
        ],
        resize_keyboard: true,
        one_time_keyboard: false
      }
    });
  }

  if (text === '❌ Selesai') {
    await bot.sendMessage(chatId, '👋 Baik, sampai jumpa lagi dengan waifu selanjutnya!', {
      reply_markup: {
        remove_keyboard: true
      }
    });
  }
});


const jobs = [
  { title: "Web Developer", emoji: "💻", desc: "Membuat dan mengelola situs web modern." },
  { title: "Mobile App Developer", emoji: "📱", desc: "Membangun aplikasi Android/iOS." },
  { title: "UI/UX Designer", emoji: "🎨", desc: "Merancang antarmuka yang nyaman digunakan." },
  { title: "Graphic Designer", emoji: "🖌️", desc: "Membuat desain visual kreatif." },
  { title: "Backend Developer", emoji: "🧠", desc: "Mengelola logika dan database aplikasi." },
  { title: "Frontend Developer", emoji: "🖼️", desc: "Mengembangkan tampilan antarmuka pengguna." },
  { title: "Fullstack Developer", emoji: "🔁", desc: "Menguasai frontend dan backend sekaligus." },
  { title: "DevOps Engineer", emoji: "⚙️", desc: "Mengotomatisasi dan menjaga infrastruktur." },
  { title: "System Administrator", emoji: "🖥️", desc: "Mengelola dan memantau server dan jaringan." },
  { title: "Software Tester (QA)", emoji: "🧪", desc: "Mengidentifikasi dan melaporkan bug." },
  { title: "Project Manager", emoji: "📋", desc: "Mengelola alur kerja dan tim proyek." },
  { title: "Product Manager", emoji: "📦", desc: "Mengembangkan strategi produk digital." },
  { title: "Game Developer", emoji: "🎮", desc: "Membuat game digital untuk berbagai platform." },
  { title: "Game Designer", emoji: "🕹️", desc: "Merancang gameplay dan mekanika permainan." },
  { title: "Cybersecurity Specialist", emoji: "🔐", desc: "Melindungi sistem dari ancaman siber." },
  { title: "Data Analyst", emoji: "📊", desc: "Mengolah data untuk pengambilan keputusan." },
  { title: "Data Scientist", emoji: "🧬", desc: "Menganalisis data untuk insight mendalam." },
  { title: "AI Engineer", emoji: "🤖", desc: "Membangun sistem berbasis kecerdasan buatan." },
  { title: "Machine Learning Engineer", emoji: "📈", desc: "Membuat model prediksi dan otomatisasi." },
  { title: "Blockchain Developer", emoji: "⛓️", desc: "Mengembangkan aplikasi berbasis blockchain." },
  { title: "Database Administrator", emoji: "🗃️", desc: "Merancang dan memelihara database." },
  { title: "Cloud Architect", emoji: "☁️", desc: "Mendesain solusi berbasis cloud." },
  { title: "Network Engineer", emoji: "🌐", desc: "Menjaga konektivitas jaringan tetap stabil." },
  { title: "IT Support Specialist", emoji: "🧰", desc: "Memberikan bantuan teknis ke pengguna." },
  { title: "Digital Marketer", emoji: "📢", desc: "Mengelola strategi pemasaran digital." },
  { title: "Content Writer", emoji: "✍️", desc: "Menulis konten untuk web dan media sosial." },
  { title: "SEO Specialist", emoji: "🔎", desc: "Mengoptimalkan peringkat pencarian Google." },
  { title: "Social Media Manager", emoji: "📱", desc: "Menjalankan kampanye medsos brand." },
  { title: "Business Analyst", emoji: "💼", desc: "Menganalisis kebutuhan dan proses bisnis." },
  { title: "Tech Lead", emoji: "🧑‍💻", desc: "Memimpin tim teknis dalam proyek." },
  { title: "Freelancer", emoji: "🧳", desc: "Pekerja lepas lintas proyek dan klien." },
  { title: "Startup Founder", emoji: "🚀", desc: "Mendirikan dan memimpin startup." },
  { title: "Video Editor", emoji: "🎞️", desc: "Mengedit video untuk konten digital." },
  { title: "3D Artist", emoji: "🧱", desc: "Membuat grafik dan animasi 3D." },
  { title: "AR/VR Developer", emoji: "🕶️", desc: "Mengembangkan aplikasi realitas virtual." },
  { title: "Motion Graphic Designer", emoji: "🎬", desc: "Membuat animasi grafis bergerak." },
  { title: "Technical Writer", emoji: "📘", desc: "Menulis dokumentasi teknis & panduan." },
  { title: "Embedded Systems Engineer", emoji: "🔌", desc: "Mengembangkan software untuk hardware." },
  { title: "IoT Developer", emoji: "📡", desc: "Menghubungkan perangkat pintar." },
  { title: "Software Architect", emoji: "🏗️", desc: "Mendesain struktur sistem perangkat lunak." },
  { title: "Scrum Master", emoji: "🏁", desc: "Memfasilitasi metode agile & sprint." },
  { title: "Penetration Tester", emoji: "🧨", desc: "Menguji keamanan sistem dengan ethical hacking." },
  { title: "UI Animator", emoji: "💫", desc: "Menambahkan animasi ke antarmuka aplikasi." },
  { title: "VR Game Designer", emoji: "🎧", desc: "Membuat pengalaman game VR." },
  { title: "Mobile Game Developer", emoji: "📲", desc: "Membangun game untuk smartphone." },
  { title: "Automation Engineer", emoji: "🤖", desc: "Mengotomatisasi proses manual." },
  { title: "Cloud Engineer", emoji: "🌥️", desc: "Mengelola infrastruktur cloud modern." },
  { title: "Financial Analyst", emoji: "💹", desc: "Menganalisis dan meramalkan keuangan." },
  { title: "Quant Developer", emoji: "📐", desc: "Membuat model finansial untuk trading." },
  { title: "Legal Tech Specialist", emoji: "⚖️", desc: "Menggabungkan hukum dan teknologi." },
  { title: "Bioinformatics Engineer", emoji: "🧫", desc: "Mengolah data biologis dan genetik." },
  { title: "EdTech Specialist", emoji: "🎓", desc: "Mengembangkan solusi teknologi pendidikan." },
  { title: "HealthTech Engineer", emoji: "🩺", desc: "Menciptakan inovasi di bidang kesehatan." },
  { title: "Robotics Engineer", emoji: "🤖", desc: "Merancang dan membangun robot." },
  { title: "Technical Recruiter", emoji: "🕵️", desc: "Mencari talenta teknologi terbaik." },
  { title: "IT Auditor", emoji: "📑", desc: "Meninjau sistem TI untuk kepatuhan dan keamanan." },
  { title: "E-Commerce Specialist", emoji: "🛒", desc: "Mengelola toko online dan penjualan digital." },
  { title: "CRM Administrator", emoji: "🗂️", desc: "Mengelola sistem hubungan pelanggan." },
  { title: "Email Marketing Specialist", emoji: "📧", desc: "Merancang kampanye email yang efektif." },
  { title: "No-Code Developer", emoji: "🧩", desc: "Membangun aplikasi tanpa menulis kode." }
];

function hashUsername(username) {
  if (!username) return Math.floor(Math.random() * jobs.length);
  let hash = 0;
  for (let i = 0; i < username.length; i++) {
    hash += username.charCodeAt(i) * (i + 1);
  }
  return hash % jobs.length;
}

bot.onText(/^\/profil(?:\s+(.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const targetUsername = match[1]
    ? match[1].replace(/^@/, '')
    : (msg.from.username || msg.from.first_name);

  const index = hashUsername(targetUsername);
  const job = jobs[index];

  const text = `
<b>👤 Profil Pengguna</b>
👨‍💼 Username: @${targetUsername}
${job.emoji} <b>${job.title}</b>
📝 <i>${job.desc}</i>
`;

  bot.sendMessage(chatId, text.trim(), { parse_mode: 'HTML' });
});

