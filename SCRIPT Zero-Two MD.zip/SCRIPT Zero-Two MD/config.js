module.exports = {
  BOT_TOKEN: "7709912019:AAEfE8zJ4P_QhmxMBbdfVKN2-liw9w9AKgA",
  OWNER_ID: ["6282298313"],
  ADMIN_ID: '6282298313',
  linkSaluran: "https://t.me/AllAboutZeroTwo",
  linkGrup: "https://t.me/LilBotDev"
};